-- Use MediaPlayer's source selector, rather than accessing providers' files or credentials.
local ICON = "icon.svg"
local views = {}
local corners = {}
local switching = false

local function current_id()
  return MediaPlayer.provider and MediaPlayer.provider.id or ""
end

local function selected_ids()
  local saved = nari.get("sources")
  -- Keep the pair chosen in earlier releases, but never assume Navidrome for new installs.
  if saved == nil then
    local legacy = nari.get("online_source")
    if type(legacy) == "string" and legacy ~= "" and legacy ~= "local" then
      saved = { "local", legacy }
    end
  end
  local ids, seen = {}, {}
  for _, id in ipairs(type(saved) == "table" and saved or {}) do
    if type(id) == "string" and id ~= "" and not seen[id] then
      table.insert(ids, id)
      seen[id] = true
    end
  end
  return ids
end

local function name_of(id)
  local provider = MediaPlayer:get_provider(id)
  if provider then return provider.display_name end
  if id == "subsonic" then return "Navidrome" end
  if id == "local" then return "Local files" end
  return id ~= "" and id or "None"
end

local function available_ids(ids)
  local available = {}
  for _, id in ipairs(ids) do
    if MediaPlayer:get_provider(id) then table.insert(available, id) end
  end
  return available
end

local function target_id()
  local ids = available_ids(selected_ids())
  if #ids < 2 then return nil end
  for index, id in ipairs(ids) do
    if id == current_id() then return ids[index % #ids + 1] end
  end
  return ids[1]
end

local function source_names()
  local names = {}
  for _, id in ipairs(selected_ids()) do table.insert(names, name_of(id)) end
  return #names > 0 and table.concat(names, " → ") or "None selected"
end

local function open_setup()
  Main:change_page(Main.Pages.Settings, Dictionary({ category = "library" }))
end

local function refresh()
  local target = target_id()
  for view in pairs(views) do
    view.status.text = "Current source: " .. name_of(current_id())
    view.toggle.text = target and "Switch to " .. name_of(target) or "Choose sources"
    view.sources.text = "Choose sources (" .. #selected_ids() .. ")"
  end
  for _, corner in pairs(corners) do
    corner.tooltip_text = target and name_of(current_id()) .. " → " .. name_of(target)
      .. "\nClick to switch (stops playback). Right-click or long-press to choose sources."
      or "Choose at least two sources to switch between."
  end
end

local function switch_to(id, browse)
  if switching or id == current_id() then return end
  -- Check before stopping: a disabled/uninstalled source must not interrupt playback.
  if not MediaPlayer:get_provider(id) then
    Snackbar.post("Source unavailable", "Enable " .. name_of(id) .. " or choose other sources.")
    return
  end
  switching = true
  local ok, problem = pcall(function()
    -- Same sequence as Nari's Settings source selector. Stop also cancels pending play jobs.
    MediaPlayer:stop()
    MediaPlayer:use_provider(id)
    if current_id() ~= id then error("Nari could not select " .. name_of(id)) end
    refresh()
    Snackbar.post("Source: " .. name_of(id), "Playback stopped. Tap here to configure this source.", open_setup)
    if browse then
      -- Discard old album/artist history so source-specific IDs cannot cross libraries.
      Main:go_home()
      Main:change_page(Main.Pages.Tracks)
    end
  end)
  switching = false
  if not ok then
    nari.warn("Source switch failed: " .. tostring(problem))
    Snackbar.post("Could not switch source", "Open Library settings to check the source.", open_setup)
  end
end

local function choose_sources()
  local draft, options, seen = selected_ids(), {}, {}
  for _, provider in ipairs(MediaPlayer.providers) do
    if not seen[provider.id] then
      table.insert(options, { id = provider.id, label = provider.display_name })
      seen[provider.id] = true
    end
  end
  for _, id in ipairs(draft) do
    if not seen[id] then
      table.insert(options, { id = id, label = name_of(id) .. " (unavailable)" })
    end
  end
  local dialog = Dialog.menu("Choose sources", "Pick two or more. The button switches in the order you pick them.")
  local scroll = ScrollContainer.new()
  scroll.horizontal_scroll_mode = 0
  scroll.custom_minimum_size = Vector2(0, math.min(#options, 3) * 80)
  dialog.content:add_child(scroll)
  local column = VBoxContainer.new()
  column.size_flags_horizontal = 3
  scroll:add_child(column)
  for _, option in ipairs(options) do
    local id, selected = option.id, false
    for _, chosen in ipairs(draft) do if chosen == id then selected = true end end
    local control = dialog:make_toggle(option.label, selected, function(on)
      for index = #draft, 1, -1 do
        if draft[index] == id then table.remove(draft, index) end
      end
      if on then table.insert(draft, id) end
    end)
    control.font_size = 28
    control.custom_minimum_size = Vector2(0, 80)
    control.padding_left = 16
    control.padding_right = 16
    control.icon_size = Vector2(32, 32)
    column:add_child(control)
  end
  local help = NariLabel.new()
  help.text = "Missing Spotify, YouTube Music, or another source? Install and enable its music provider plugin first."
  help.autowrap_mode = 3
  dialog.content:add_child(help)
  dialog:add_button("Cancel")
  dialog:add_button("Save", function()
    if #available_ids(draft) < 2 then
      Snackbar.post("Pick at least two sources", "Choose two available sources, then tap Save.")
      return
    end
    nari.set("sources", draft)
    refresh()
    dialog:close()
  end, 1, false) -- PRIMARY; keep the picker open if validation fails.
  dialog:popup()
end

local function toggle(browse)
  local target = target_id()
  if target then switch_to(target, browse) else choose_sources() end
end

local function settings_entries()
  return {
    {
      title = "Switch source",
      description = "Switches immediately and stops playback.",
      icon = ICON,
      value = function() return name_of(current_id()) end,
      action = function() toggle(true) end,
    },
    {
      title = "Choose sources",
      description = "Pick the sources you want the button to switch between.",
      icon = ICON,
      value = source_names,
      action = choose_sources,
    },
    {
      title = "Configure current source",
      description = "Set up folders or sign in to this source.",
      icon = "res://assets/icons/settings.svg",
      action = open_setup,
    },
  }
end

local function button(parent, text, action)
  local control = NariButton.new()
  control.text = text
  control.focus_mode = 2 -- Control.FOCUS_ALL: keyboard and controller focus.
  control.custom_minimum_size = Vector2(0, 64)
  control.clip_text = true
  control.pressed:connect(action)
  parent:add_child(control)
  return control
end

local function build_tab(area)
  local scroll = ScrollContainer.new()
  scroll.horizontal_scroll_mode = 0 -- Disabled: fit narrow phone/handheld screens.
  area:add_child(scroll)
  local column = VBoxContainer.new()
  column.size_flags_horizontal = 3 -- SIZE_EXPAND_FILL
  column:add_theme_constant_override("separation", 16)
  scroll:add_child(column)

  local status = NariLabel.new()
  status.font_size = 24
  status.autowrap_mode = 3 -- TextServer.AUTOWRAP_WORD_SMART
  column:add_child(status)
  local view = { status = status }
  view.toggle = button(column, "Switch source", function() toggle(true) end)
  view.toggle.icon = nari.load(ICON)
  view.sources = button(column, "Choose sources", choose_sources)
  button(column, "Configure current source", open_setup)
  local note = NariLabel.new()
  note.text = "Switching stops the music and opens your tracks. Your source settings stay saved."
  note.autowrap_mode = 3
  column:add_child(note)
  views[view] = true
  -- Remove references as pages close; never update freed Godot controls.
  area.tree_exiting:connect(function() views[view] = nil end)
  refresh()
end

local function mount_corner(name, page)
  -- Login webviews and the initial setup screen should keep their own controls.
  if name == "Welcome" or name == "Web" or not page or not page.top then return end
  local parent = page.top
  local id = parent:get_instance_id()
  if corners[id] then return end

  -- A separate Control keeps anchors working even on pages built with Containers.
  -- It follows the page's safe area, below the status bar and above the player.
  local overlay = Control.new()
  overlay.name = "SourceSwitcherOverlay"
  overlay.mouse_filter = 2 -- MOUSE_FILTER_IGNORE; only the button catches clicks.
  overlay.z_index = 100
  parent:add_child(overlay)
  overlay:set_anchors_and_offsets_preset(15) -- PRESET_FULL_RECT

  local corner = NariButton.new()
  corner.name = "QuickSourceSwitch"
  corner.text = ""
  corner.icon = nari.load(ICON)
  corner.icon_size = Vector2(40, 40)
  corner.custom_minimum_size = Vector2(72, 72)
  corner.corner_radius = 36
  corner.padding = 12
  corner.use_custom_colors = true
  corner.custom_bg_color = Color("#29090e")
  corner.custom_gradient_color = Color("#b51a28")
  corner.custom_fg_color = Color("#ffffff")
  corner.use_icon_color = false -- Use the white custom foreground, including dark themes.
  corner.focus_mode = 2 -- Keyboard/controller accessible without stealing initial focus.
  corner.pressed:connect(function() toggle(true) end)
  corner.context_requested:connect(choose_sources)
  overlay:add_child(corner)
  corner.anchor_left = 1
  corner.anchor_right = 1
  corner.offset_left = -88
  corner.offset_right = -16
  corner.offset_top = 16
  corner.offset_bottom = 88
  corner.grow_horizontal = 0 -- Grow to the left if a theme adds extra padding.
  corners[id] = corner
  overlay.tree_exiting:connect(function() corners[id] = nil end)
  refresh()
end

nari.now_playing_tab({ id = "sources", title = "Sources", icon = ICON, build = build_tab })
nari.settings(settings_entries)
MediaPlayer.music_provider_changed:connect(refresh)
nari.on("page", mount_corner)
nari.on("disable", function() views = {}; corners = {} end)

# Quick Source Switcher

Pick your music sources. Tap the red corner button to switch between them. Switching stops the music and opens your tracks.

## Setup

1. Install `source-switcher-1.2.0.zip` in **Settings → Plugins → Install plugin** and enable it.
2. Tap the corner button and pick two or more sources, then tap **Save**.
3. Tap the button again to switch. Sources cycle in the order you picked them.

To change your picks, right-click or hold the button, open the plugin's **Choose sources** setting, or use **Now Playing → Sources**.

Local files, Navidrome, Plex, Spotify, YouTube Music, and other music providers can be selected when available in Nari. Install and enable a service's music provider plugin first if it is missing, then sign in through its settings. This plugin switches sources; it does not add streaming services itself.

Your picks stay saved. Disabled sources are skipped until enabled again. Updates keep your old source pair.

By Pirate2122yt

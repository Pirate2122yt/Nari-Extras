# Quick Source Switcher

Switch music sources with a red corner button. Switching stops playback and opens your tracks.

## Setup

1. Install `source-switcher-1.2.3.zip` through **Settings → Plugins → Install plugin**, then enable it.
2. Tap the corner button, pick two or more sources, and tap **Save**.
3. Tap again to switch. Sources cycle in the order you picked them.

Right-click or hold the button to change your choices. You can also use **Now Playing → Sources** or the plugin's settings. On touchscreens, swipe over source rows to scroll.

Sources must already be installed and configured in Nari. Local files, Navidrome, Plex, Spotify and YouTube Music appear when a compatible provider is available. Unavailable sources are skipped; your choices stay saved across updates.

No additional permissions are required. Edit `name`, `description` or `author` in `manifest.json` to customize the plugin; keep its ID unchanged.

By Pirate2122yt

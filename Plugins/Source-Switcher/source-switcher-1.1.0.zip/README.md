# Quick Source Switcher

A Lua plugin for Nari plugin API 1. Switch between your existing **Local files** library and **Navidrome** with one press. No extra permissions or separate credentials are needed.

## Install and use

1. Install `source-switcher-1.1.0.zip` in **Settings → Plugins → Install plugin**, then enable **Quick Source Switcher**. Installing this version replaces version 1.0.0 and keeps the saved online-source preference.
2. Configure your sources once in **Settings → Library**: select **Local files** and add your music folder(s), then select **Navidrome** and sign in. Both configurations remain saved.
3. Press the **red circular button with white switching arrows in the upper-right corner**, just below the status/header area. It is available across your music screens, including Home. Local files switches to Navidrome; an online source switches back to Local files. Each press stops playback and opens Tracks for the selected source. The former Home carousel entry is replaced by this compact button.
4. You can also open **Now Playing → Sources** and press the button labeled **Switch to …**. The panel shows the current source.

In the plugin's settings (the cog beside it in Settings → Plugins), **Online source** changes the other side of the switch to any registered online provider, including Plex and enabled music-provider plugins. The Sources tab has the same picker. Choosing this preference does not interrupt playback.

Right-click or long-press the corner button to open the online-source picker. Hovering shows the current and destination sources. The button uses a bold white glyph on a deep red circular background with a brighter red gradient to match the supplied dark red theme. It stays anchored when the window resizes, supports keyboard/controller focus, and does not grab focus when a screen opens.

**Configure current source** opens Nari's Library settings. The notification after a switch opens the same settings when tapped. If a source is not configured yet, use this to add folders or sign in. If a selected provider plugin is disabled or removed, switching to it shows a message without stopping your music; choose another source or re-enable it.

## Behavior and limits

- Uses Nari's saved provider configuration and built-in source selector; it never reads server passwords or scans folders itself.
- The local side includes all folders selected in Nari. This does not create separate profiles for individual folders or multiple Navidrome accounts.
- Switching stops the current playback session, as Nari's own source selector does. It does not resume separate queues or positions for each source.
- Online connectivity, authentication, and offline downloads continue to be managed by Nari. This plugin does not automatically change Offline mode or fall back when a server is unreachable.
- An unavailable preferred source is kept as a preference rather than silently substituted.
- The corner button follows each page's safe area on the main screen, leaving the status bar and bottom player alone. Setup and embedded login screens do not show it. The transparent overlay around it lets clicks reach the screen underneath.
- Now Playing's Sources tab uses Nari's own UI extension point on single and dual screens. Reopen Now Playing if you enabled or reloaded the plugin while it was already open. The corner button also attaches to the screen already open when the plugin is enabled.

## Build

From the repository root:

```powershell
python scripts/package_source_switcher.py
```

The installable ZIP is written to `build/plugins/source-switcher-1.1.0.zip`. To package manually, zip `manifest.json`, `main.lua`, `icon.svg`, and this README at the root of the archive (or together inside one folder).

## Verification

Run `python scripts/tests/test_source_switcher.py` with the Python package `lupa` installed. It runs behavior tests in Lua 5.4 against Nari/Godot test doubles and checks the ZIP contents. It covers source switching, preferences, missing providers, error recovery, UI updates, and view cleanup. This does not test rendering or real server playback.

For an in-app check, configure both sources, press the corner button in each direction, and play a track from each library. Resize the window and confirm it remains in the upper-right safe area. Check right-click/long-press, keyboard/controller focus, and the Sources tab. Disable the plugin and confirm the corner button disappears. Automated tests do not replace an in-app visual check.

## References

- [First plugin and manifests](https://narimusic.com/docs/plugins/)
- [UI extensions](https://narimusic.com/docs/plugins/ui/)
- [Lifecycle](https://narimusic.com/docs/plugins/how-plugins-run/)
- [Debugging](https://narimusic.com/docs/plugins/debugging/)

Enable Developer mode and use F12 for errors; F5 reloads installed plugin files. Editing this repository's copy requires repackaging and reinstalling it, or copying it to Nari's plugin directory.

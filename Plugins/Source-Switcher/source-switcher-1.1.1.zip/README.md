# Quick Source Switcher

Tap the red button in the top-right corner to switch between local music and Navidrome. Switching stops the music and opens your tracks.

## Setup

1. Install `source-switcher-1.1.1.zip` in **Settings → Plugins → Install plugin** and enable it.
2. Add your music folder and sign in to Navidrome in **Settings → Library**.
3. Tap the corner button to switch!

Right-click or hold the button to choose a different online source. You can also use **Now Playing → Sources**.

Your folders and login stay saved. Updates keep your chosen source.

By Pirate2122yt

# Quick Source Switcher

Pick your music sources. Tap the red corner button to switch between them. Switching stops the music and opens your tracks.

## Setup

1. Install `source-switcher-1.2.0.zip` in **Settings → Plugins → Install plugin** and enable it.
2. Tap the corner button and pick two or more sources, then tap **Save**.
3. Tap the button again to switch. Sources cycle in the order you picked them.

To change your picks, right-click or hold the button, open the plugin's **Choose sources** setting, or use **Now Playing → Sources**.

Local files, Navidrome, Plex, Spotify, YouTube Music, and other music providers can be selected when available in Nari. Install and enable a service's music provider plugin first if it is missing, then sign in through its settings. This plugin switches sources; it does not add streaming services itself.

Your picks stay saved. Disabled sources are skipped until enabled again. Updates keep your old source pair.

## Change the name and details

Open `manifest.json` in this folder. Edit `name`, `description`, `author`, and `version` to change what Nari shows. Use `\n` for a new line in the description.

Keep `id`, `api`, `main`, `icon`, and `permissions` as they are for this plugin. Keeping the same `id` lets updates keep your saved source choices.

After editing, zip the files again and install the updated ZIP in Nari. If you are working in the source repository, run `python scripts/package_source_switcher.py` to build it for you.

By Pirate2122yt

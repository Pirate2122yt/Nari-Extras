-- Use MediaPlayer's source selector, rather than accessing providers' files or credentials.
local ICON = "icon.svg"
local views = {}
local switching = false

local function current_id()
  return MediaPlayer.provider and MediaPlayer.provider.id or ""
end

local function online_id()
  local saved = nari.get("online_source")
  return type(saved) == "string" and saved ~= "" and saved ~= "local" and saved or "subsonic"
end

local function name_of(id)
  local provider = MediaPlayer:get_provider(id)
  if provider then return provider.display_name end
  if id == "subsonic" then return "Navidrome" end
  if id == "local" then return "Local files" end
  return id ~= "" and id or "None"
end

local function target_id()
  return current_id() == "local" and online_id() or "local"
end

local function open_setup()
  Main:change_page(Main.Pages.Settings, Dictionary({ category = "library" }))
end

local function refresh()
  for view in pairs(views) do
    view.status.text = "Current source: " .. name_of(current_id())
    view.toggle.text = "Switch to " .. name_of(target_id())
    view.online.text = "Online source: " .. name_of(online_id())
  end
end

local function remember_online(id)
  nari.set("online_source", id)
  refresh()
end

local function switch_to(id, browse)
  if switching or id == current_id() then return end
  -- Check before stopping: a disabled/uninstalled source must not interrupt playback.
  if not MediaPlayer:get_provider(id) then
    Snackbar.post("Source unavailable", "Enable " .. name_of(id) .. " or choose another online source.")
    return
  end
  switching = true
  local ok, problem = pcall(function()
    -- Same sequence as Nari's Settings source selector. Stop also cancels pending play jobs.
    MediaPlayer:stop()
    MediaPlayer:use_provider(id)
    if current_id() ~= id then error("Nari could not select " .. name_of(id)) end
    if id ~= "local" then remember_online(id) end
    refresh()
    Snackbar.post("Source: " .. name_of(id), "Playback stopped. Tap here to configure this source.", open_setup)
    if browse then
      -- Discard old album/artist history so source-specific IDs cannot cross libraries.
      Main:go_home()
      Main:change_page(Main.Pages.Tracks)
    end
  end)
  switching = false
  if not ok then
    nari.warn("Source switch failed: " .. tostring(problem))
    Snackbar.post("Could not switch source", "Open Library settings to check the source.", open_setup)
  end
end

local function toggle(browse)
  switch_to(target_id(), browse)
end

local function online_options()
  local options = {}
  for _, provider in ipairs(MediaPlayer.providers) do
    if provider.id ~= "local" then
      table.insert(options, { value = provider.id, label = provider.display_name })
    end
  end
  return options
end

local function choose_online()
  local options = online_options()
  if #options == 0 then
    Snackbar.post("No online sources", "Enable an online music provider first.")
    return
  end
  local dialog = Dialog.menu("Online source", "The switch alternates between Local files and this source.")
  for _, option in ipairs(options) do
    local id = option.value
    local label = option.label .. (id == online_id() and " (selected)" or "")
    dialog:add_option(label, function() remember_online(id) end)
  end
  dialog:add_button("Cancel")
  dialog:popup()
end

local function settings_entries()
  return {
    {
      title = "Switch source",
      description = "Switches immediately and stops playback.",
      icon = ICON,
      value = function() return name_of(current_id()) end,
      action = function() toggle(true) end,
    },
    {
      title = "Online source",
      description = "Alternate between Local files and this source. Configure its account in Library settings.",
      icon = ICON,
      value = function() return name_of(online_id()) end,
      choices = { options = online_options(), get = online_id, set = remember_online },
    },
    {
      title = "Configure current source",
      description = "Select your local music folders or sign in to your server.",
      icon = "res://assets/icons/settings.svg",
      action = open_setup,
    },
  }
end

local function button(parent, text, action)
  local control = NariButton.new()
  control.text = text
  control.focus_mode = 2 -- Control.FOCUS_ALL: keyboard and controller focus.
  control.custom_minimum_size = Vector2(0, 64)
  control.clip_text = true
  control.pressed:connect(action)
  parent:add_child(control)
  return control
end

local function build_tab(area)
  local scroll = ScrollContainer.new()
  scroll.horizontal_scroll_mode = 0 -- Disabled: fit narrow phone/handheld screens.
  area:add_child(scroll)
  local column = VBoxContainer.new()
  column.size_flags_horizontal = 3 -- SIZE_EXPAND_FILL
  column:add_theme_constant_override("separation", 16)
  scroll:add_child(column)

  local status = NariLabel.new()
  status.font_size = 24
  status.autowrap_mode = 3 -- TextServer.AUTOWRAP_WORD_SMART
  column:add_child(status)
  local view = { status = status }
  view.toggle = button(column, "Switch source", function() toggle(true) end)
  view.toggle.icon = nari.load(ICON)
  view.online = button(column, "Online source", choose_online)
  button(column, "Configure current source", open_setup)
  local note = NariLabel.new()
  note.text = "Switching stops playback and opens the selected library. Your folders and server login stay saved."
  note.autowrap_mode = 3
  column:add_child(note)
  views[view] = true
  -- Remove references as pages close; never update freed Godot controls.
  area.tree_exiting:connect(function() views[view] = nil end)
  refresh()
end

nari.home_entry({
  title = "Switch source",
  subtitle = "Local files / online source. One press switches and stops playback.",
  icon = ICON,
  color = "Teal",
  action = function() toggle(true) end,
})
nari.now_playing_tab({ id = "sources", title = "Sources", icon = ICON, build = build_tab })
nari.settings(settings_entries)
MediaPlayer.music_provider_changed:connect(refresh)
nari.on("disable", function() views = {} end)

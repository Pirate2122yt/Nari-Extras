# Quick Source Switcher

A Lua plugin for Nari plugin API 1. Switch between your existing **Local files** library and **Navidrome** with one press. No extra permissions or separate credentials are needed.

## Install and use

1. Install `source-switcher-1.0.0.zip` in **Settings → Plugins → Install plugin**, then enable **Quick Source Switcher**.
2. Configure your sources once in **Settings → Library**: select **Local files** and add your music folder(s), then select **Navidrome** and sign in. Both configurations remain saved.
3. Return to **Home**, then select **Switch source**. Local files switches to Navidrome; an online source switches back to Local files. Each press stops playback and opens Tracks for the selected source.
4. You can also open **Now Playing → Sources** and press the button labeled **Switch to …**. The panel shows the current source.

In the plugin's settings (the cog beside it in Settings → Plugins), **Online source** changes the other side of the switch to any registered online provider, including Plex and enabled music-provider plugins. The Sources tab has the same picker. Choosing this preference does not interrupt playback.

**Configure current source** opens Nari's Library settings. The notification after a switch opens the same settings when tapped. If a source is not configured yet, use this to add folders or sign in. If a selected provider plugin is disabled or removed, switching to it shows a message without stopping your music; choose another source or re-enable it.

## Behavior and limits

- Uses Nari's saved provider configuration and built-in source selector; it never reads server passwords or scans folders itself.
- The local side includes all folders selected in Nari. This does not create separate profiles for individual folders or multiple Navidrome accounts.
- Switching stops the current playback session, as Nari's own source selector does. It does not resume separate queues or positions for each source.
- Online connectivity, authentication, and offline downloads continue to be managed by Nari. This plugin does not automatically change Offline mode or fall back when a server is unreachable.
- An unavailable preferred source is kept as a preference rather than silently substituted.
- Home and Now Playing use Nari's own UI extension points on single and dual screens. Reopen the screen if you enabled or reloaded the plugin while it was already open.

## Build

From the repository root:

```powershell
python scripts/package_source_switcher.py
```

The installable ZIP is written to `build/plugins/source-switcher-1.0.0.zip`. To package manually, zip `manifest.json`, `main.lua`, `icon.svg`, and this README at the root of the archive (or together inside one folder).

## Verification

Run `python scripts/tests/test_source_switcher.py` with the Python package `lupa` installed. It runs behavior tests in Lua 5.4 against Nari/Godot test doubles and checks the ZIP contents. It covers source switching, preferences, missing providers, error recovery, UI updates, and view cleanup. This does not test rendering or real server playback.

For an in-app check, configure both sources, switch from Home in each direction, and play a track from each library. Repeat from Now Playing's Sources tab. Test touch or controller navigation on your device, then disable the plugin and reopen the screen to check cleanup.

## References

- [First plugin and manifests](https://narimusic.com/docs/plugins/)
- [UI extensions](https://narimusic.com/docs/plugins/ui/)
- [Lifecycle](https://narimusic.com/docs/plugins/how-plugins-run/)
- [Debugging](https://narimusic.com/docs/plugins/debugging/)

Enable Developer mode and use F12 for errors; F5 reloads installed plugin files. Editing this repository's copy requires repackaging and reinstalling it, or copying it to Nari's plugin directory.

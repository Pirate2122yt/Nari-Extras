local interface
local engine = require("engine").new(function() if interface then interface:refresh() end end)
interface = require("ui").new(engine)

nari.home_entry({ title = "Queue Tools", subtitle = "Clean up what plays next", icon = "icon.svg", color = "Red", action = function() interface:open() end })
nari.now_playing_tab({ id = "queue_tools", title = "Queue tools", icon = "icon.svg", build = function(parent) interface:build(parent) end })
nari.item_action({ title = "Play with Queue Tools…", kinds = { "playlist" }, icon = "icon.svg", action = function(_, data) interface:open(data) end })
nari.settings(function() return { { title = "Open Queue Tools", icon = "icon.svg", action = function() interface:open() end } } end)
nari.on("disable", function() engine:stop(); interface:close_all() end)

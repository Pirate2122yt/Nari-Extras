local model = require("model")
local M = {}

function M.new(changed)
  local self = { busy = false, alive = true, message = "Choose a tool for the songs coming up.", limit = nari.get("artist_limit") or 3 }
  if type(self.limit) ~= "number" or self.limit < 1 or self.limit > 10 or self.limit ~= math.floor(self.limit) then self.limit = 3 end
  local function emit() if self.alive then changed(self) end end
  local function stamp()
    local state = MediaPlayer:get_playback_state()
    return { provider = MediaPlayer.provider and MediaPlayer.provider.id or "", session = MediaPlayer.play_session,
      current = state.current_id or "", index = state.index or -1, version = state.queue_version,
      size = state.queue_size, shuffle = state.shuffle }
  end
  local function same(a, b)
    return a.provider == b.provider and a.session == b.session and a.current == b.current
      and a.index == b.index and a.version == b.version and a.shuffle == b.shuffle
  end
  local function finish(message)
    self.busy, self.message = false, message
    emit()
  end
  local function fail(problem)
    if not self.alive then return end
    nari.warn("Queue Tools: " .. tostring(problem))
    finish("Couldn't finish. Your queue may have changed; try again.")
    Snackbar.post("Queue Tools", self.message)
  end
  local function safe(action)
    if not self.alive then return end
    local ok, problem = pcall(action)
    if not ok then fail(problem) end
  end
  local function snapshot(done, attempts)
    attempts = attempts or 0
    local before = stamp()
    nari.await(MediaPlayer:get_queue(), function(queue) safe(function()
      local after = stamp()
      assert(same(before, after), "Queue changed while reading")
      assert(type(queue) == "table", "Queue unavailable")
      -- Playback notifications arrive after native edits. Wait for the state
      -- and queue to agree before using any positional indices.
      if after.size ~= nil and after.size ~= #queue then
        assert(attempts < 8, "Waiting for queue update")
        nari.after(0.03, function() safe(function() snapshot(done, attempts + 1) end) end)
        return
      end
      if #queue > 0 then
        assert(after.index >= 0 and after.index < #queue and model.id(queue[after.index + 1]) == after.current, "Current song changed")
      end
      done(queue, after)
    end) end)
  end
  local function begin(message)
    if not self.alive or self.busy then return false end
    self.busy, self.message = true, message
    emit()
    return true
  end
  function self:set_limit(value)
    if self.busy or not self.alive then return end
    assert(value == math.floor(value) and value >= 1 and value <= 10)
    nari.set("artist_limit", value)
    self.limit = value
    emit()
  end
  function self:run(mode)
    if not begin("Reading your queue…") then return end
    local origin = stamp()
    safe(function() snapshot(function(queue, initial)
      assert(same(origin, initial), "Playback changed before edits began")
      if #queue == 0 or initial.index >= #queue - 1 then finish("There are no upcoming songs. Play a playlist or add some songs first."); return end
      local plan = model.plan(queue, initial.index, mode, self.limit)
      if #plan.operations == 0 then finish(mode == "shuffle" and "The upcoming queue is already in this order." or "No songs needed removing."); return end
      local next_operation, applied = 1, 0
      local expected = {}
      for index, track in ipairs(queue) do expected[index] = track end
      local function step()
        safe(function() snapshot(function(actual, current)
          if current.provider ~= initial.provider or current.session ~= initial.session or current.index ~= initial.index
            or current.current ~= initial.current or current.shuffle ~= initial.shuffle or not model.same_queue(actual, expected) then
            finish(applied == 0 and "The queue changed. Try again." or "The queue changed. Stopped after " .. applied .. " edits; finished edits were kept.")
            return
          end
          if next_operation > #plan.operations then
            finish(mode == "shuffle" and "Shuffled " .. #plan.tracks .. " upcoming songs."
              or mode == "artists" and "Applied the artist limit; removed " .. plan.removed .. " upcoming songs."
              or "Removed " .. plan.removed .. " upcoming repeats.")
            return
          end
          -- Small batches let long playlist queues stay responsive. Recheck
          -- the actual queue between batches to protect a newly started song.
          for _ = 1, 24 do
            local operation = plan.operations[next_operation]
            if not operation then break end
            if operation.kind == "remove" then MediaPlayer:remove_from_queue(operation.from)
            else MediaPlayer:move_in_queue(operation.from, operation.to) end
            model.apply_expected(expected, operation)
            next_operation, applied = next_operation + 1, applied + 1
          end
          nari.after(0, step)
        end) end)
      end
      step()
    end) end)
  end
  function self:play_playlist(data, mode)
    if not begin("Loading the whole playlist…") then return end
    local origin, tracks = stamp(), {}
    local function ready()
      assert(same(origin, stamp()), "Playback or source changed while loading playlist")
      if #tracks == 0 then finish("This playlist is empty or couldn't be loaded."); return end
      if type(data.song_count) == "number" and data.song_count > 0 then
        if #tracks ~= data.song_count then finish("The playlist changed or did not finish loading. Reopen it and try again."); return end
      end
      local plan = model.plan(tracks, -1, mode, self.limit)
      assert(#plan.tracks > 0, "No playable songs")
      -- Public playback API registers streamed tracks through the active source.
      -- Only a playback queue is created; no playlist write API is used.
      MediaPlayer:play_tracks(plan.tracks, "", false)
      finish("Starting " .. #plan.tracks .. " songs from " .. (data.name or "your playlist") .. ".")
    end
    local function page(offset)
      assert(same(origin, stamp()), "Playback changed while loading playlist")
      nari.await(MediaPlayer:get_page("playlist", data.id, offset, 200), function(result) safe(function()
        assert(same(origin, stamp()), "Source changed while loading playlist")
        assert(type(result) == "table" and type(result.items) == "table", "Playlist unavailable")
        for _, track in ipairs(result.items) do tracks[#tracks + 1] = track end
        if result.more then
          assert(#result.items > 0, "Playlist page did not load")
          nari.after(0, function() safe(function() page(#tracks) end) end)
        else ready() end
      end) end)
    end
    safe(function()
      assert(type(data.id) == "string" and data.id ~= "", "Playlist has no ID")
      if data.id == "liked" then
        nari.await(MediaPlayer:get_playlist(data.id), function(result) safe(function()
          assert(type(result) == "table" and type(result.tracks) == "table", "Liked songs unavailable")
          tracks = result.tracks; ready()
        end) end)
      else page(0) end
    end)
  end
  function self:stop() self.alive, self.busy = false, false end
  return self
end

return M

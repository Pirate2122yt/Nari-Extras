-- Plans edits against occurrence positions, so repeated playlist entries do
-- not get confused with each other. Native queue indices are zero based.
local M = {}
local function normalized(value)
  return type(value) == "string" and value:lower():gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", " ") or ""
end

function M.id(track)
  return type(track) == "table" and type(track.id) == "string" and track.id or ""
end

local function artist(track)
  local name = normalized(track.artist)
  if name == "" or name == "unknown" or name == "unknown artist" or name == "various artists" then return nil end
  if type(track.artist_id) == "string" and track.artist_id ~= "" then return "id:" .. track.artist_id end
  return "name:" .. name
end

function M.same_queue(a, b)
  if #a ~= #b then return false end
  for index, track in ipairs(a) do if M.id(track) ~= M.id(b[index]) then return false end end
  return true
end

function M.plan(queue, current, mode, limit, random)
  assert(type(queue) == "table" and type(current) == "number" and current == math.floor(current)
    and current >= -1 and current < #queue, "Queue is not ready")
  assert(mode == "duplicates" or mode == "shuffle" or mode == "artists", "Unknown queue tool")
  limit = limit or 3
  assert(type(limit) == "number" and limit >= 1 and limit <= 10 and limit == math.floor(limit), "Choose an artist limit from 1 to 10")
  local prefix, count = current + 1, #queue - current - 1
  local order, keep, seen, artists = {}, {}, {}, {}
  if current >= 0 and M.id(queue[current + 1]) ~= "" then seen[M.id(queue[current + 1])] = true end
  for index = 1, count do
    local track, selected = queue[prefix + index], true
    assert(type(track) == "table" and M.id(track) ~= "", "A queue entry has no song ID")
    if mode == "duplicates" then
      selected = not seen[track.id]
      seen[track.id] = true
    elseif mode == "artists" then
      local key = artist(track)
      if key then
        artists[key] = (artists[key] or 0) + 1
        selected = artists[key] <= limit
      end
    end
    if selected then order[#order + 1], keep[index] = index, true end
  end
  if mode == "shuffle" then
    random = random or math.random
    for index = #order, 2, -1 do
      local other = random(index)
      order[index], order[other] = order[other], order[index]
    end
  end
  local operations, removed, tracks = {}, 0, {}
  for index = count, 1, -1 do
    if not keep[index] then
      operations[#operations + 1] = { kind = "remove", from = prefix + index - 1 }
      removed = removed + 1
    end
  end
  -- A Fenwick tree finds each remaining occurrence's position in O(log n).
  -- Pulling selected entries to the front preserves the others' relative order.
  local tree = {}
  local function update(index, amount)
    while index <= count do tree[index] = (tree[index] or 0) + amount; index = index + (index & -index) end
  end
  local function rank(index)
    local total = 0
    while index > 0 do total = total + (tree[index] or 0); index = index - (index & -index) end
    return total
  end
  for index in pairs(keep) do update(index, 1) end
  for position, original in ipairs(order) do
    tracks[#tracks + 1] = queue[prefix + original]
    local from, to = prefix + position + rank(original) - 2, prefix + position - 1
    if from ~= to then operations[#operations + 1] = { kind = "move", from = from, to = to } end
    update(original, -1)
  end
  return { operations = operations, removed = removed, tracks = tracks }
end

function M.apply_expected(queue, operation)
  local item = table.remove(queue, operation.from + 1)
  if operation.kind == "move" then table.insert(queue, operation.to + 1, item) end
end

return M

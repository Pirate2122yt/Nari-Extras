# Queue Tools

Remove repeats, shuffle upcoming songs, or limit songs per artist. Compatible with **Nari 1.2**.

## Setup

1. Install `queue-tools-1.0.4.zip` through **Settings → Plugins → Install plugin**, then enable it.
2. Open **Home → Queue Tools** or **Now Playing → Queue tools**.
3. Pick a tool. Use **Artist limit** to choose 1, 2, 3, 5 or 10 songs per artist.

Tools change only the upcoming queue, keeping the current song and playback position. Saved playlists stay unchanged. Different song IDs count as different versions; songs without usable artist credits are excluded from artist limits.

## Playlists

Choose **Play with Queue Tools…** from a playlist's menu to start a fresh queue without duplicates, shuffled, or with an artist limit. This replaces the playing queue and also works with Liked songs.

If playback or the queue changes during an edit, remaining edits stop. Completed edits remain; there is no undo.

Close with **Close** or **Escape**. No additional permissions are required. Updates keep your artist-limit setting.

By Pirate2122yt

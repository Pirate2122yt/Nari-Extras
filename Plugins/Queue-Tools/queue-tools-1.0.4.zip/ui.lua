local M = {}
local ICON = "icon.svg"

local function dialog_panel(dialog)
  local node = dialog.content:get_parent()
  while node do
    if node:is_class("PanelContainer") then return node end
    node = node:get_parent()
  end
end

local function label(parent, text, size, muted)
  local control = NariLabel.new()
  control.text, control.font_size, control.autowrap_mode = text, size, 3
  control.mouse_filter = 1
  control.use_custom_color, control.custom_color = true, Color(muted and "#cbb6bf" or "#fff4f7")
  parent:add_child(control)
  return control
end

local function button(parent, text, action)
  local control = NariButton.new()
  control.text, control.font_size, control.padding, control.corner_radius = text, 40, 16, 20
  control.custom_minimum_size, control.focus_mode = Vector2(0, 96), 2
  control.mouse_filter = 1 -- Let touch drags reach the scroll view.
  -- A wrapped Label in NariButton's internal BoxContainer can collapse to 1px
  -- high. Keep button text single-line, with an ellipsis on narrow screens.
  control.autowrap_mode, control.clip_text, control.text_overrun_behavior = 0, true, 3
  control.use_custom_colors = true
  control.custom_bg_color, control.custom_gradient_color, control.custom_fg_color = Color("#3c1423"), Color("#8b2941"), Color("#fff5f8")
  control.pressed:connect(action)
  parent:add_child(control)
  return control
end

function M.new(engine)
  local views, dialogs = {}, {}
  local self = {}
  local choose_limit
  local function build(parent, playlist)
    local root = VBoxContainer.new()
    root.size_flags_horizontal, root.size_flags_vertical, root.mouse_filter = 3, 3, 1
    root:add_theme_constant_override("separation", 24)
    parent:add_child(root)
    label(root, playlist and (playlist.name or "Your playlist") or "Queue tools", 64)
    local scroll = ScrollContainer.new()
    scroll.size_flags_horizontal, scroll.size_flags_vertical = 3, 3
    scroll.horizontal_scroll_mode, scroll.mouse_filter, scroll.mouse_force_pass_scroll_events = 0, 0, false
    scroll.follow_focus = true
    root:add_child(scroll)
    local body = VBoxContainer.new()
    body.size_flags_horizontal, body.mouse_filter = 3, 1
    body:add_theme_constant_override("separation", 20)
    scroll:add_child(body)
    label(body, playlist and "Start a fresh queue from this playlist." or "Clean up what plays next.", 36, true)
    local view = { status = label(body, "", 36), buttons = {}, playlist = playlist ~= nil }
    local function action(mode)
      if playlist then engine:play_playlist(playlist, mode) else engine:run(mode) end
    end
    view.buttons[1] = button(body, playlist and "Play without duplicates" or "Remove duplicates", function() action("duplicates") end)
    view.buttons[2] = button(body, playlist and "Shuffle and play" or "Shuffle upcoming", function() action("shuffle") end)
    view.artist = button(body, "", function() action("artists") end)
    view.buttons[3] = view.artist
    view.limit = button(body, "", choose_limit)
    view.buttons[4] = view.limit
    label(body, playlist and "Your saved playlist stays unchanged." or "Works with playlist queues. Keeps your current song playing and leaves saved playlists unchanged.", 32, true)
    label(body, "By Pirate2122yt", 28, true)
    views[view] = true
    root.tree_exiting:connect(function() views[view] = nil end)
    self:refresh()
    return root
  end
  local function popup(dialog, area)
    local panel = dialog_panel(dialog)
    if panel then
      panel.padding, panel.corner_radius, panel.use_custom_colors = 32, 32, true
      panel.custom_bg_color, panel.custom_gradient_color = Color("#160d14"), Color("#401322")
    end
    local alive, queued = true, false
    local viewport = Main:input_root():get_viewport()
    local function fit()
      if not alive then return end
      local size = viewport:get_visible_rect().size
      if panel then panel.custom_minimum_size = Vector2(math.max(240, math.min(1600, size.x * 0.92)), 0) end
      if area then area.custom_minimum_size = Vector2(0, math.max(120, math.min(1050, size.y * 0.82 - 180))) end
    end
    local function schedule()
      if queued or not alive then return end
      queued = true
      nari.after(0, function() queued = false; fit() end)
    end
    dialog.dismissable = false
    dialog:add_button("Close")
    for _, control in ipairs(dialog.footer:get_children()) do
      control.font_size, control.custom_minimum_size = 36, Vector2(180, 80)
    end
    dialog:popup()
    viewport = dialog:get_viewport()
    local disconnect_resize = viewport.size_changed:connect(schedule)
    local disconnect_size = panel and panel.minimum_size_changed:connect(function()
      local width = math.max(240, math.min(1600, viewport:get_visible_rect().size.x * 0.92))
      if panel.custom_minimum_size.x ~= width then schedule() end
    end) or function() end
    local window = dialog:get_window()
    local disconnect_key = window.window_input:connect(function(event)
      if not alive or Main:input_root() ~= dialog then return end
      if event:is_class("InputEventKey") and event.pressed and not event.echo
        and (event.keycode == 4194305 or event.physical_keycode == 4194305) then
        window:set_input_as_handled(); viewport:set_input_as_handled(); dialog:close()
      end
    end)
    local function cleanup()
      if not alive then return end
      alive = false
      disconnect_resize(); disconnect_size(); disconnect_key()
      dialogs[dialog] = nil
    end
    dialogs[dialog] = true
    dialog.closed:connect(cleanup)
    dialog.tree_exiting:connect(cleanup)
    fit()
  end
  choose_limit = function()
    if engine.busy then return end
    local dialog = Dialog.new()
    label(dialog.content, "Songs per artist", 48)
    for _, amount in ipairs({ 1, 2, 3, 5, 10 }) do
      local value = amount
      local control = dialog:add_option(tostring(value) .. (value == 1 and " song" or " songs"), function() engine:set_limit(value) end)
      control.font_size, control.custom_minimum_size = 40, Vector2(0, 96)
    end
    popup(dialog)
  end
  function self:refresh()
    for view in pairs(views) do
      view.status.text = engine.message
      view.artist.text = (view.playlist and "Play: max " or "Keep up to ") .. engine.limit .. (engine.limit == 1 and " song per artist" or " songs per artist")
      view.limit.text = "Artist limit: " .. engine.limit .. " — change"
      for _, control in ipairs(view.buttons) do control.disabled = engine.busy end
    end
  end
  function self:build(parent) return build(parent) end
  function self:open(playlist)
    local dialog = Dialog.new()
    local area = MarginContainer.new()
    dialog.content:add_child(area)
    build(area, playlist)
    popup(dialog, area)
  end
  function self:close_all()
    for dialog in pairs(dialogs) do dialog:close() end
    views, dialogs = {}, {}
  end
  return self
end

return M

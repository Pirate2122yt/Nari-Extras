-- Responsive native Nari UI. Update existing controls without resetting scroll/focus.
local M = {}
local RED, MUTED = "#ff8d9f", "#c2b1bc"
-- Nari's desktop canvas is scaled against a 2160px reference height. Use the
-- same generous sizing as its own menus rather than tiny web-dashboard units.
local function u(value) return value * 2 end

local function gap(container, amount)
  container:add_theme_constant_override("separation", u(amount))
end

local function label(parent, name, text, size, color, single_line)
  local control = NariLabel.new()
  control.name, control.text, control.font_size = name, text, u(size)
  control.weight = size >= 24 and 600 or 500
  control.use_custom_color, control.custom_color = true, Color(color or "#fff5f7")
  control.autowrap_mode = single_line and 0 or 3
  if single_line then
    control.clip_text, control.max_lines_visible = true, 1
    control.text_overrun_behavior = 3 -- TRIM_ELLIPSIS
  end
  parent:add_child(control)
  return control
end

local function panel(parent, name)
  local control = NariPanelContainer.new()
  control.name, control.padding, control.corner_radius = name, u(18), u(18)
  control.use_custom_colors = true
  control.custom_bg_color, control.custom_gradient_color = Color("#20131d"), Color("#491a2a")
  control.size_flags_horizontal, control.size_flags_vertical = 3, 3
  parent:add_child(control)
  local column = VBoxContainer.new()
  gap(column, 10)
  control:add_child(column)
  return control, column
end

local function button(parent, name, text, action, width)
  local control = NariButton.new()
  control.name, control.text, control.font_size = name, text, u(20)
  control.custom_minimum_size = Vector2(u(width or 100), u(44))
  control.padding, control.corner_radius = u(8), u(12)
  control.padding_left, control.padding_right = u(14), u(14)
  control.use_custom_colors = true
  control.custom_bg_color, control.custom_gradient_color = Color("#321824"), Color("#651f32")
  control.custom_fg_color = Color("#fff5f7")
  control.focus_mode, control.size_flags_horizontal = 2, 0
  control.clip_text = true
  control.pressed:connect(action)
  parent:add_child(control)
  return control
end

local function metric(parent, name, caption)
  local _, column = panel(parent, name .. "Tile")
  local value = label(column, name .. "Value", "0", 40)
  label(column, name .. "Caption", caption, 16, MUTED)
  return value
end

local function ranking(parent, name, title)
  local card, column = panel(parent, name)
  card.custom_minimum_size = Vector2(0, u(220))
  label(column, name .. "Heading", title, 23)
  local empty = label(column, name .. "Empty", "Your favorites will appear here.", 18, MUTED)
  local rows = {}
  for index = 1, 5 do
    local row = HBoxContainer.new()
    row.custom_minimum_size = Vector2(0, u(54))
    gap(row, 10)
    column:add_child(row)
    local number = label(row, name .. "Rank" .. index, tostring(index), 17, RED, true)
    number.custom_minimum_size = Vector2(u(22), 0)
    number.size_flags_vertical = 4
    local texts = VBoxContainer.new()
    texts.size_flags_horizontal = 3
    gap(texts, 3)
    row:add_child(texts)
    local heading = label(texts, name .. "Name" .. index, "", 20, nil, true)
    local subtitle = label(texts, name .. "Subtitle" .. index, "", 16, MUTED, true)
    local count = label(row, name .. "Count" .. index, "", 17, RED, true)
    count.custom_minimum_size, count.size_flags_vertical = Vector2(u(55), 0), 4
    count.horizontal_alignment = 2
    rows[index] = { root = row, heading = heading, subtitle = subtitle, count = count }
  end
  return { rows = rows, empty = empty }
end

local function update_ranking(view, entries)
  view.empty.visible = #entries == 0
  for index, row in ipairs(view.rows) do
    local entry = entries[index]
    row.root.visible = entry ~= nil
    if entry then
      row.heading.text, row.heading.tooltip_text = entry.name, entry.name
      row.subtitle.text = entry.subtitle or math.floor(entry.seconds / 60) .. " min listened"
      row.subtitle.tooltip_text = row.subtitle.text
      row.count.text = tostring(entry.plays)
      row.count.tooltip_text = entry.plays .. " counted plays"
    end
  end
end

local function pass_report_gestures(control)
  -- The report body is read-only. PanelContainer defaults to STOP, which
  -- otherwise traps touch drags on cards before ScrollContainer sees them.
  -- PASS keeps label tooltips while letting the scroll view own each swipe.
  control.mouse_filter = 1 -- MOUSE_FILTER_PASS
  for _, child in ipairs(control:get_children()) do pass_report_gestures(child) end
end

function M.build(parent, actions)
  local root = VBoxContainer.new()
  root.name = "WrappedDashboard"
  root.size_flags_horizontal, root.size_flags_vertical = 3, 3
  gap(root, 18)
  parent:add_child(root)

  local header = HBoxContainer.new()
  gap(header, 16)
  root:add_child(header)
  local logo = TextureRect.new()
  logo.texture = nari.load("logo.png")
  logo.expand_mode, logo.stretch_mode = 1, 5 -- Ignore texture size, keep aspect centered.
  logo.custom_minimum_size = Vector2(u(64), u(64))
  header:add_child(logo)
  local titles = VBoxContainer.new()
  titles.size_flags_horizontal = 3
  gap(titles, 2)
  header:add_child(titles)
  label(titles, "WrappedBrand", "LISTENING WRAPPED", 14, RED)
  local heading = label(titles, "WrappedPeriod", "Your music story", 30)

  local toolbar = HFlowContainer.new()
  toolbar.name = "WrappedToolbar"
  toolbar:add_theme_constant_override("h_separation", u(8))
  toolbar:add_theme_constant_override("v_separation", u(8))
  root:add_child(toolbar)
  button(toolbar, "PreviousPeriod", "‹", actions.previous, 48)
  local month = button(toolbar, "ThisMonth", "This month", actions.month, 128)
  local year = button(toolbar, "ThisYear", "This year", actions.year, 112)
  button(toolbar, "NextPeriod", "›", actions.next, 48)
  local share = button(toolbar, "SaveShareCard", "Save card", actions.share, 128)
  share.custom_bg_color, share.custom_gradient_color = Color("#922c42"), Color("#d44360")
  button(toolbar, "MoreActions", "More…", actions.more, 100)

  local scroll = ScrollContainer.new()
  scroll.name = "WrappedScroll"
  scroll.size_flags_horizontal, scroll.size_flags_vertical = 3, 3
  scroll.horizontal_scroll_mode, scroll.mouse_filter = 0, 0
  scroll.mouse_force_pass_scroll_events, scroll.follow_focus = false, true
  root:add_child(scroll)
  local body = VBoxContainer.new()
  body.name, body.size_flags_horizontal = "WrappedBody", 3
  gap(body, 18)
  scroll:add_child(body)

  local metrics = GridContainer.new()
  metrics.name, metrics.columns = "WrappedMetrics", 4
  metrics:add_theme_constant_override("h_separation", u(12))
  metrics:add_theme_constant_override("v_separation", u(12))
  body:add_child(metrics)
  local values = {
    minutes = metric(metrics, "Minutes", "minutes listened"),
    plays = metric(metrics, "Plays", "counted plays"),
    songs = metric(metrics, "Songs", "unique songs"),
    days = metric(metrics, "Days", "active days"),
  }

  local empty, empty_body = panel(body, "WrappedEmptyState")
  label(empty_body, "EmptyHeading", "Your story starts with one song.", 26)
  label(empty_body, "EmptyDescription", "Listen with Wrapped enabled, then come back to see your favorites. Earlier listening cannot be recreated.", 20, MUTED)

  local ranks = GridContainer.new()
  ranks.name, ranks.columns = "WrappedRankings", 3
  ranks:add_theme_constant_override("h_separation", u(14))
  ranks:add_theme_constant_override("v_separation", u(14))
  body:add_child(ranks)
  local lists = {
    artists = ranking(ranks, "TopArtists", "Top artists"),
    tracks = ranking(ranks, "TopSongs", "Top songs"),
    albums = ranking(ranks, "TopAlbums", "Top albums"),
  }
  local details = label(body, "WrappedHighlights", "", 18, MUTED)
  label(body, "WrappedNote", "Minutes are approximate. Plays count after half a song or four minutes. Stats start when Wrapped is enabled.", 15, MUTED)
  label(body, "WrappedCredit", "By Pirate2122yt", 14, MUTED)
  -- Limit this to the report content: toolbar buttons and the scroll view
  -- itself must still consume their input (including wheel events at edges).
  pass_report_gestures(body)

  local function reflow()
    local width = root.size.x / 2
    -- The dialog is built before it enters the scene tree. Its first resize
    -- supplies the real width; no viewport lookup is safe before popup().
    metrics.columns = width >= 760 and 4 or (width >= 380 and 2 or 1)
    ranks.columns = width >= 1000 and 3 or 1
    share.visible = width >= 700
  end
  local disconnect = root.resized:connect(reflow)
  reflow()

  local view = { root = root, scroll = scroll, cleanup = disconnect }
  function view:update(result)
    local stats = result.stats
    heading.text = result.label
    values.minutes.text, values.plays.text = tostring(math.floor(stats.seconds / 60)), tostring(stats.plays)
    values.songs.text, values.days.text = tostring(stats.unique_tracks), tostring(stats.days)
    details.text = string.format("%d-day streak  ·  %d songs new to your Wrapped", stats.streak, stats.new_tracks)
    empty.visible = stats.plays == 0 and stats.seconds == 0
    ranks.visible = not empty.visible
    for key, list in pairs(lists) do update_ranking(list, stats[key]) end
    month.custom_bg_color = Color(result.mode == "month" and "#762438" or "#321824")
    year.custom_bg_color = Color(result.mode == "year" and "#762438" or "#321824")
  end
  return view
end

return M

# Listening Wrapped

Your month or year in music: top songs, artists and albums, approximate listening minutes, active days, streaks, and songs new to your Wrapped.

## Get started

1. Install `listening-wrapped-1.2.0.zip` in **Settings → Plugins → Install plugin**, then enable it.
2. Listen normally, using any music source.
3. Open **Home → Listening Wrapped** or **Now Playing → Wrapped**.
4. Use **This month**, **This year**, and the arrow buttons to browse periods. **Save card** exports a PNG, with an SVG fallback.

The desktop dashboard fills about 94% of the window width and 92% of its height, with larger text and controls. It shows stat tiles and three ranking columns and adapts to smaller windows. **More…** contains history import/export, refresh and help. Save card is also available there on narrow screens.

Scroll inside the report to see the rest. On phones, swipe anywhere on the stats, text or ranking cards to scroll. Close it with **Close** or **Escape**. Escape closes the frontmost Wrapped popup first, so leaving the period picker keeps the report open. Updating the plugin keeps your collected history.

Tracking starts when the plugin is enabled. It cannot recreate earlier months from Nari's built-in history. It keeps working with the screen off while Nari and its audio service are running. You can pause collection in the plugin's settings.

Minutes measure approximate time with playback active, including partial songs; they are not the sum of song lengths. Seeking does not add minutes. Plays follow Nari's rule: half a song or four minutes, for tracks at least 30 seconds long. The collector saves at most once a minute during continuous playback; closing the app or disabling the plugin can lose up to the most recent minute. Device sleep, buffering, casting, clock changes and speed effects can affect the time estimate. Periods use the viewing device's time zone. Artist collaborations use the credited artist field. Songs match across sources by normalized title, artist and album, so different metadata can split the same song.

## Backups and saved files

Use **Export history** to save a JSON backup and **Import history** to restore it. Import every part if a backup contains several files. Reimporting the same records does not increase the counts. Exports and cards go to the plugin's data folder; the saved-file dialog shows the path. On Android, access to this app-private folder depends on the device.

## Your data

Wrapped runs entirely on your device and requires no permissions. History backups include song titles, credited artists, albums, timestamps, approximate listening intervals and record IDs. Saved cards include only the selected summary. Export a backup before uninstalling: uninstalling deletes the local history.

Up to 40,000 records are retained (each counted play and each saved listening interval is a record). At the limit, the collector reports that storage is full and stops adding records; it never silently deletes older history. Large backups are split into small files to fit Nari's file picker.

By Pirate2122yt

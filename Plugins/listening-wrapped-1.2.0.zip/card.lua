-- Render PNG text with Godot's font system; SVG image loaders may omit text.
local M = {}

function M.save(parent, stats, period, path, done)
  local viewport
  local ok, problem = pcall(function()
    viewport = SubViewport.new()
    viewport.size = Vector2i(1080, 1350)
    viewport.disable_3d = true
    viewport.render_target_update_mode = 4 -- UPDATE_ALWAYS until capture completes.
    parent:add_child(viewport)
    local canvas = Control.new()
    canvas.size = Vector2(1080, 1350)
    viewport:add_child(canvas)

    local gradient = Gradient.new()
    gradient:set_color(0, Color("#250b22"))
    gradient:set_color(1, Color("#090c1c"))
    local texture = GradientTexture2D.new()
    texture.gradient, texture.width, texture.height = gradient, 1080, 1350
    texture.fill_from, texture.fill_to = Vector2(0, 0), Vector2(1, 1)
    local background = TextureRect.new()
    background.texture, background.size = texture, Vector2(1080, 1350)
    canvas:add_child(background)

    local function line(x, y, size, value, color, width)
      local label = NariLabel.new()
      label.text, label.font_size, label.weight = tostring(value), size, 600
      label.use_custom_color, label.custom_color = true, Color(color or "#ffffff")
      label.clip_text, label.max_lines_visible = true, 1
      label.position, label.size = Vector2(x, y - size), Vector2(width or 940, size * 1.5)
      canvas:add_child(label)
    end
    line(70, 100, 26, "LISTENING WRAPPED", "#ff8ca8")
    line(70, 180, 60, period)
    line(70, 290, 92, math.floor(stats.seconds / 60), nil, 450)
    line(70, 335, 26, "minutes of music", "#ccbed8")
    line(580, 290, 92, stats.plays, nil, 430)
    line(580, 335, 26, "counted plays", "#ccbed8", 430)
    line(70, 405, 25, stats.unique_tracks .. " songs  •  " .. stats.days .. " days  •  " .. stats.streak .. "-day streak")
    line(70, 490, 34, "Your top artists")
    local maximum = stats.artists[1] and math.max(stats.artists[1].plays, 1) or 1
    for index = 1, math.min(3, #stats.artists) do
      local artist, y = stats.artists[index], 550 + (index - 1) * 115
      line(70, y, 30, index .. ". " .. artist.name, nil, 780)
      line(900, y, 28, artist.plays, nil, 100)
      local bar = ColorRect.new()
      bar.color = Color(index == 1 and "#fa496b" or "#bb8aff")
      bar.position = Vector2(70, y + 24)
      bar.size = Vector2(math.max(12, math.floor(880 * artist.plays / maximum)), 12)
      canvas:add_child(bar)
    end
    line(70, 935, 34, "On repeat")
    local top = stats.tracks[1]
    line(70, 1000, 38, top and top.name or "Your story starts here")
    line(70, 1045, 28, top and top.subtitle or "Listen with Wrapped enabled.", "#ccbed8")
    line(70, 1120, 26, stats.new_tracks .. " songs new to your Wrapped")
    line(70, 1230, 21, "Approximate time tracked while playback is active.", "#b6a8c0")
    line(70, 1270, 21, "Nari  •  By Pirate2122yt", "#b6a8c0")
  end)
  if not ok then
    if viewport then viewport:queue_free() end
    return done(nil, tostring(problem))
  end
  nari.after(0.3, function()
    local captured, saved = pcall(function()
      local image = viewport:get_texture():get_image()
      return image and not image:is_empty() and image:save_png(path) == 0
    end)
    viewport:queue_free()
    done(captured and saved and path or nil)
  end)
end

return M

-- One writer owns the journal. It runs beside audio even when Android pauses the UI.
local model = require("model")
local journal = nari.get("journal")
if journal == nil then
  journal = { schema = model.SCHEMA, device = nari.sha256(nari.random_bytes(32)):sub(1, 32), seq = 0, events = {} }
else
  assert(type(journal) == "table" and type(journal.device) == "string" and journal.device:match("^[a-f0-9]+$") and #journal.device == 32, "Invalid Wrapped journal; restore a backup before continuing")
  journal.events = model.merge({}, journal)
end
local index = model.index(journal.events)
local sequence = 0
local function update_sequence()
  for id in pairs(index) do
    local device, number = id:match("^([^:]+):(%d+)$")
    if device == journal.device then sequence = math.max(sequence, tonumber(number)) end
  end
  journal.seq = sequence
end
update_sequence()
local function save() nari.set("journal", journal) end
save()

local function payload(events)
  -- Preserve a JSON array for empty histories (plain empty Lua tables may encode as {}).
  return #events == 0 and nari.json_decode('{"schema":1,"events":[]}') or { schema = model.SCHEMA, events = events }
end

local song, playing, last_tick = nil, false, os.time()
local full_warning = false
local function recording() return nari.get("paused") ~= true end
local function append(kind, at, details, seconds)
  if #journal.events >= model.LIMIT then
    if not full_warning then
      nari.send({ type = "error", message = "Wrapped history is full. Export a backup; new records cannot be saved." })
      full_warning = true
    end
    return false
  end
  sequence = sequence + 1
  local event = model.track(details)
  event.id, event.kind, event.at, event.seconds = journal.device .. ":" .. sequence, kind, at, seconds
  event = model.validate(event)
  table.insert(journal.events, event)
  index[event.id], journal.seq = event, sequence
  save()
  return true
end

local function flush()
  local now = os.time()
  local elapsed = now - last_tick
  -- Ignore suspension/clock jumps instead of claiming hours of unobserved playback.
  if song and playing and recording() and elapsed > 0 and elapsed <= 120 then
    append("time", last_tick, song, elapsed)
  end
  last_tick = now
end

nari.on("track", function(value)
  flush()
  song = type(value) == "table" and value or nil
end)
nari.on("state", function(state)
  flush()
  playing = state.playing == true
end)
nari.on("played", function(value)
  flush()
  if recording() and type(value) == "table" then
    -- Date a play when its threshold is reached, never before collection started.
    append("play", os.time(), value)
  end
end)

local function write_file(name, content)
  local path = nari.plugin.data .. "/" .. name
  local temporary = path .. ".tmp"
  local file = assert(io.open(temporary, "wb"))
  assert(file:write(content))
  assert(file:close())
  -- Lua's Windows rename cannot replace an existing file. Keep a previous export
  -- until the new file is complete; unique request suffixes avoid replacement.
  assert(os.rename(temporary, path))
  return path
end

nari.on("message", function(request)
  local ok, result = pcall(function()
    flush()
    if request.action == "summary" then
      local start, finish, label = model.period(request.year, request.month, request.mode)
      return { stats = model.summary(journal.events, start, finish), label = label, records = #journal.events }
    elseif request.action == "snapshot" then
      return { payload = payload(journal.events) }
    elseif request.action == "merge" then
      local merged, added = model.merge(journal.events, request.payload)
      -- Commit the new journal only after the complete import passes validation.
      nari.set("journal", { schema = model.SCHEMA, device = journal.device, seq = sequence, events = merged })
      journal.events, index = merged, model.index(merged)
      update_sequence()
      return { added = added }
    elseif request.action == "export" then
      -- Nari's text picker accepts up to 4 MiB. Keep every part below 1 MiB so
      -- large histories can still be transferred with the built-in file picker.
      local parts, part, bytes = {}, {}, 0
      for _, event in ipairs(journal.events) do
        local size = #nari.json_encode(event) + 1
        if bytes + size > 1000000 and #part > 0 then table.insert(parts, part); part, bytes = {}, 0 end
        table.insert(part, event)
        bytes = bytes + size
      end
      table.insert(parts, part)
      local paths = {}
      for index, events in ipairs(parts) do
        table.insert(paths, write_file("wrapped-history-" .. os.time() .. "-" .. request.request_id .. "-part" .. index .. ".json", nari.json_encode(payload(events))))
      end
      return { paths = paths }
    elseif request.action == "card" then
      local start, finish, label = model.period(request.year, request.month, request.mode)
      local stats = model.summary(journal.events, start, finish)
      return { path = write_file("wrapped-card-" .. os.time() .. "-" .. request.request_id .. ".svg", model.card(stats, label)), stats = stats, label = label }
    elseif request.action == "pause" then
      nari.set("paused", request.paused == true)
      last_tick = os.time()
      return { paused = request.paused == true }
    end
    error("Unknown Wrapped request")
  end)
  nari.send({ type = "reply", request_id = request.request_id, result = ok and result or nil, error = not ok and tostring(result) or nil })
end)

local function heartbeat()
  flush()
  nari.after(60, heartbeat)
end
nari.after(60, heartbeat)

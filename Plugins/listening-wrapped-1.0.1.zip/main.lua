local ICON = "icon.svg"
local card = require("card")
local today = os.date("*t")
local year, month, mode = today.year, today.month, "month"
local worker = nari.thread("collector.lua")
local pending, request_id, views = {}, 0, {}
local sync_busy = false

local function request(action, values, callback)
  request_id = request_id + 1
  local message = values or {}
  message.action, message.request_id = action, request_id
  if callback then pending[request_id] = callback end
  worker:send(message)
end

worker:on_message(function(message)
  if message.type == "error" then
    Snackbar.post("Listening Wrapped", message.message)
  elseif message.type == "reply" then
    local callback = pending[message.request_id]
    pending[message.request_id] = nil
    if message.error then Snackbar.post("Wrapped couldn't finish", message.error) end
    if callback then callback(message.result, message.error) end
  end
end)
worker:on_error(function(problem)
  sync_busy = false
  pending = {}
  Snackbar.post("Wrapped collector stopped", tostring(problem))
end)

local function label(parent, text, size)
  local control = NariLabel.new()
  control.text, control.font_size, control.autowrap_mode = text, size or 22, 3
  parent:add_child(control)
  return control
end

local function button(parent, text, action)
  local control = NariButton.new()
  control.text, control.font_size = text, 24
  control.focus_mode = 2
  control.custom_minimum_size = Vector2(0, 64)
  control.clip_text = true
  control.pressed:connect(action)
  parent:add_child(control)
  return control
end

local function rank_text(entries)
  local lines = {}
  for index = 1, math.min(5, #entries) do
    local item = entries[index]
    local subtitle = item.subtitle and " — " .. item.subtitle or ""
    table.insert(lines, index .. ". " .. item.name .. subtitle .. "  ·  " .. item.plays .. " plays")
  end
  return #lines > 0 and table.concat(lines, "\n") or "Nothing yet. Keep listening!"
end

local function refresh()
  local asked_year, asked_month, asked_mode = year, month, mode
  request("summary", { year = year, month = month, mode = mode }, function(result)
    if not result or year ~= asked_year or month ~= asked_month or mode ~= asked_mode then return end
    local stats = result.stats
    for view in pairs(views) do
      view.heading.text = "Your " .. result.label .. " Wrapped"
      view.totals.text = string.format("%d minutes  ·  %d plays\n%d songs  ·  %d active days  ·  %d-day streak", math.floor(stats.seconds / 60), stats.plays, stats.unique_tracks, stats.days, stats.streak)
      view.artists.text = rank_text(stats.artists)
      view.tracks.text = rank_text(stats.tracks)
      view.albums.text = rank_text(stats.albums)
      view.details.text = stats.new_tracks .. " songs new to your Wrapped\n" .. stats.devices .. " device(s) in this period\n" .. result.records .. " / 40000 saved records"
    end
  end)
end

local function period_menu()
  today = os.date("*t")
  local dialog = Dialog.menu("Pick a period")
  dialog:add_option("This month", function() year, month, mode = today.year, today.month, "month"; refresh() end)
  dialog:add_option("This year", function() year, mode = today.year, "year"; refresh() end)
  dialog:add_option("Previous period", function()
    if mode == "year" then year = math.max(1970, year - 1)
    else month = month - 1; if month == 0 then month, year = 12, math.max(1970, year - 1) end end
    refresh()
  end)
  dialog:add_option("Next period", function()
    if mode == "year" then year = math.min(3000, year + 1)
    else month = month + 1; if month == 13 then month, year = 1, math.min(3000, year + 1) end end
    refresh()
  end)
  dialog:add_button("Cancel")
  dialog:popup()
end

local function saved_file(path)
  local dialog = Dialog.menu("Saved to your Wrapped data folder", path)
  dialog:add_option("Open folder", function()
    local folder = nari.plugin.data:gsub("\\", "/")
    if folder:sub(1, 1) ~= "/" then folder = "/" .. folder end
    nari.open_url("file://" .. folder:gsub(" ", "%%20"))
  end)
  dialog:add_button("Close")
  dialog:popup()
end

local function export_history()
  request("export", nil, function(result) if result then saved_file(table.concat(result.paths, "\n")) end end)
end

local function import_history()
  nari.await(Plugins:pick_text({ "json" }), function(text)
    if text == "" then return end
    local ok, payload = pcall(nari.json_decode, text)
    if not ok then Snackbar.post("Couldn't import", "Choose a Wrapped history JSON file."); return end
    request("merge", { payload = payload }, function(result)
      if result then Snackbar.post("History merged", result.added .. " new records; duplicates skipped."); refresh() end
    end)
  end)
end

local function export_card()
  request("card", { year = year, month = month, mode = mode }, function(result)
    if not result then return end
    card.save(Main, result.stats, result.label, result.path:gsub("%.svg$", ".png"), function(png)
      saved_file(png or result.path)
    end)
  end)
end

local function sync_now()
  if sync_busy then Snackbar.post("Sync is already running"); return end
  local url, token = nari.get("sync_url"), nari.get("sync_token")
  if type(url) ~= "string" or url == "" or type(token) ~= "string" or token == "" then
    Snackbar.post("Set up sync first", "Add your private sync server URL and key in this plugin's settings.")
    return
  end
  -- Transport credentials only to an explicitly configured HTTPS server or loopback test server.
  if not url:match("^https://[^/]+") and not url:match("^http://127%.0%.0%.1:%d+$") and not url:match("^http://localhost:%d+$") then
    Snackbar.post("Use an HTTPS server URL", "Plain HTTP is allowed only on localhost for testing.")
    return
  end
  sync_busy = true
  request("snapshot", nil, function(result)
    if not result then sync_busy = false; return end
    local sent = pcall(function() nari.http({ method = "POST", url = url:gsub("/+$", "") .. "/v1/sync", headers = {
      ["Content-Type"] = "application/json", ["Authorization"] = "Bearer " .. token,
    }, body = nari.json_encode(result.payload), retries = 0 }, function(response)
      if not response or response.status ~= 200 then
        sync_busy = false
        Snackbar.post("Sync failed", "Your local history is safe. Check the server URL and key.")
        return
      end
      local ok, payload = pcall(nari.json_decode, response.body)
      if not ok then sync_busy = false; Snackbar.post("Sync failed", "The server returned invalid history."); return end
      request("merge", { payload = payload }, function(merged)
        sync_busy = false
        if merged then Snackbar.post("Wrapped synced", merged.added .. " new records from your devices."); refresh() end
      end)
    end) end)
    if not sent then
      sync_busy = false
      Snackbar.post("Sync failed", "Check the server URL and key, then try again.")
    end
  end)
end

local function build(parent)
  local scroll = ScrollContainer.new()
  scroll.horizontal_scroll_mode = 0
  -- Keep wheel presses/releases inside the report, including at its scroll limits.
  -- Otherwise Dialog's backdrop can mistake a wheel release for a dismiss click.
  scroll.mouse_filter = 0 -- MOUSE_FILTER_STOP
  scroll.mouse_force_pass_scroll_events = false
  scroll.follow_focus = true
  parent:add_child(scroll)
  local column = VBoxContainer.new()
  column.size_flags_horizontal = 3
  column:add_theme_constant_override("separation", 18)
  scroll:add_child(column)
  local view = {}
  view.heading = label(column, "Your Listening Wrapped", 36)
  view.totals = label(column, "Loading your music story…", 28)
  button(column, "Change month / year", period_menu)
  label(column, "Top artists", 28)
  view.artists = label(column, "")
  label(column, "Top songs", 28)
  view.tracks = label(column, "")
  label(column, "Top albums", 28)
  view.albums = label(column, "")
  view.details = label(column, "")
  button(column, "Save a share card", export_card)
  button(column, "Export history", export_history)
  button(column, "Import history from another device", import_history)
  button(column, "Sync now", sync_now)
  button(column, "Refresh", refresh)
  label(column, "Tracking starts when this plugin is enabled. Minutes are approximate active-playback time. A play counts after half the song or 4 minutes, for songs at least 30 seconds long. Periods use this device's time zone. Share cards show only this period's summary; history exports contain song details and timestamps.", 18)
  label(column, "By Pirate2122yt", 18)
  views[view] = true
  parent.tree_exiting:connect(function() views[view] = nil end)
  refresh()
end

local function open_wrapped()
  local dialog = Dialog.menu("Listening Wrapped")
  -- Backdrop dismissal also accepts mouse-wheel releases in current Nari builds.
  -- Close and the normal Back/Escape action still dismiss this unlocked dialog.
  dialog.dismissable = false
  local area = MarginContainer.new()
  local height = math.max(180, math.min(650, Main:input_root():get_viewport():get_visible_rect().size.y - 420))
  area.custom_minimum_size = Vector2(0, height)
  dialog.content:add_child(area)
  build(area)
  dialog:add_button("Close")
  dialog:popup()
end

nari.home_entry({ title = "Listening Wrapped", subtitle = "Your month in music", icon = ICON, color = "Purple", action = open_wrapped })
nari.now_playing_tab({ id = "wrapped", title = "Wrapped", icon = ICON, build = build })
nari.setting({ key = "sync_url", title = "Sync server URL", description = "Optional. Your own HTTPS Wrapped server; leave blank to keep everything local." })
nari.setting({ key = "sync_token", title = "Sync key", private = true, description = "Use the same private key on your devices." })
nari.settings(function() return {
  { title = "Open Wrapped", icon = ICON, action = open_wrapped },
  { title = "Collect listening history", description = "Turning this off pauses new records.", value = function() return nari.get("paused") and "Off" or "On" end,
    action = function() request("pause", { paused = nari.get("paused") ~= true }) end },
  { title = "Export history", icon = ICON, action = export_history },
  { title = "Import history", icon = ICON, action = import_history },
  { title = "Sync now", description = "Uploads and merges history with your configured server.", icon = ICON, action = sync_now },
} end)
nari.on("disable", function() pending, views = {}, {} end)

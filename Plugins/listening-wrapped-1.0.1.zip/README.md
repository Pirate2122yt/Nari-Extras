# Listening Wrapped

Your month or year in music: top songs, artists and albums, approximate listening minutes, active days, streaks, and songs new to your Wrapped.

## Get started

1. Install `listening-wrapped-1.0.1.zip` in **Settings → Plugins → Install plugin**, then enable it.
2. Listen normally, using any music source.
3. Open **Home → Listening Wrapped** or **Now Playing → Wrapped**.
4. Choose a month or year. **Save a share card** exports a PNG, with an SVG fallback.

Scroll inside the report to see the rest. Close it with **Close** or Back/Escape. Updating the plugin keeps your collected history.

Tracking starts when the plugin is enabled. It cannot recreate earlier months from Nari's built-in history. It keeps working with the screen off while Nari and its audio service are running. You can pause collection in the plugin's settings.

Minutes measure approximate time with playback active, including partial songs; they are not the sum of song lengths. Seeking does not add minutes. Plays follow Nari's rule: half a song or four minutes, for tracks at least 30 seconds long. The collector saves at most once a minute during continuous playback; closing the app or disabling the plugin can lose up to the most recent minute. Device sleep, buffering, casting, clock changes and speed effects can affect the time estimate. Periods use the viewing device's time zone. Artist collaborations use the credited artist field. Songs match across sources by normalized title, artist and album, so different metadata can split the same song.

## Two or more devices

**No server:** Export history on one device, transfer the JSON file(s), then choose **Import history** on another. Repeat in the other direction to give both devices the combined history. Import every part if several are exported. Reimporting the same records does not increase the counts. Exports go to the plugin's data folder; the saved-file dialog shows the path and can open it on desktop. On Android, access to this app-private folder depends on the device; use server sync if you cannot transfer its files.

**Optional private server:** Run the included `scripts/wrapped_sync_server.py` from the source repository, expose it through HTTPS, then enter its base URL and the same sync key on each device in the plugin settings. Press **Sync now** on each device. No account or public service is required. The server is a separate program; installing the plugin does not install or start it. See the repository's `docs/listening-wrapped-sync.md` for setup and limits.

Sync is manual, not continuous. A device uploads what it currently has and downloads the server's combined history. After A syncs, B must sync to see A; A must sync again to see any newer records B uploaded. Offline records remain on the device until the next sync. Do not copy the plugin's internal storage file between devices: export/import instead, so each device keeps its own record IDs.

## Your data

The network permission is for optional sync and opening the export folder. No history leaves the device until you press **Sync now** with a configured server. A sync server receives song titles, credited artists, albums, timestamps, approximate listening intervals and anonymous device IDs. The sync key is stored in Nari's private storage. History exports include those same listening details but no sync key. Share cards include only the selected summary. Export a backup before uninstalling: uninstalling deletes the local history.

Up to 40,000 records are retained (each counted play and each saved listening interval is a record). At the limit, the collector reports that storage is full and stops adding records; it never silently deletes older history. The optional server accepts up to 16 MiB per request and 40,000 merged records. Large manual exports are split into small files to fit Nari's file picker. This version does not provide automatic archival, per-device deletion or deletion propagation.

By Pirate2122yt

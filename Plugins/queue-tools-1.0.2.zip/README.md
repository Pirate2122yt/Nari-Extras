# Queue Tools

Remove duplicates, shuffle upcoming songs, or keep a chosen number of songs per artist.

1. Install `queue-tools-1.0.2.zip` in **Settings → Plugins → Install plugin**, then enable it.
2. Open **Home → Queue Tools** or **Now Playing → Queue tools**.
3. Pick a tool. Changes apply to the upcoming queue, including queues started from playlists, albums, liked songs or the library.

Your current song, its playback position, paused/playing state and already played queue entries are kept. Saved playlists are never edited. Removing duplicates keeps the first upcoming occurrence of each song and removes upcoming copies of the current song. Different song IDs are treated as different versions, even when their titles match.

**Shuffle upcoming** changes the upcoming order without toggling Nari's shuffle setting. Nari's own shuffle controls can subsequently replace that order. **Keep up to … songs per artist** keeps the first upcoming songs for each artist; the current song does not count toward that limit. Choose 1, 2, 3, 5 or 10 with **Artist limit**. Missing or generic artist credits are left alone. Artists are grouped by artist ID when available, otherwise by the full credited artist name.

## Start directly from a playlist

Open a playlist's context menu and choose **Play with Queue Tools…**. Choose **Play without duplicates**, **Shuffle and play**, or the artist limit tool. This reads all available playlist pages before creating a fresh playback queue. It also works with the Liked songs playlist. Starting one of these options replaces the playing queue; the saved playlist remains unchanged. To keep the current song playing, start your playlist normally and use the regular Queue Tools screen instead.

Long queue edits run in small batches. If a song advances, the source changes, or another action changes the queue, remaining edits stop. Completed edits remain applied. There is no automatic editing and no undo button. Empty queues and playlists are handled without stopping existing playback.

Close the window with **Close** or **Escape**. Scroll inside it on phones. Buttons use Nari's normal touch gestures. The plugin uses the active source through Nari's own playback API and requests no permissions. Only your chosen artist limit is saved locally.

The manifest can be edited to change the plugin's name, description and author. Keep its ID and main entry unchanged when updating.

By Pirate2122yt

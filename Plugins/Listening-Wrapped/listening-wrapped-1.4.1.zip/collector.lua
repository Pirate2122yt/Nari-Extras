-- One writer owns the journal. It runs beside audio even when Android pauses the UI.
local model = require("model")
local storage = require("storage")
local archive = storage.open()
local song, playing, last_tick = nil, false, os.time()
local save_warning = false
local function recording() return nari.get("paused") ~= true end
local function append(kind, at, details, seconds)
  local ok, problem = pcall(function() archive:append(kind, at, details, seconds) end)
  if not ok then
    if not save_warning then
      nari.send({ type = "error", message = "Couldn't save Wrapped history. Check free storage space. " .. tostring(problem) })
      save_warning = true
    end
    return false
  end
  save_warning = false
  return true
end

local function flush()
  local now = os.time()
  local elapsed = now - last_tick
  -- Ignore suspension/clock jumps instead of claiming hours of unobserved playback.
  if song and playing and recording() and elapsed > 0 and elapsed <= 120 then
    if not append("time", last_tick, song, elapsed) then return end
  end
  last_tick = now
end

nari.on("track", function(value)
  flush()
  song = type(value) == "table" and value or nil
end)
nari.on("state", function(state)
  flush()
  playing = state.playing == true
end)
nari.on("played", function(value)
  flush()
  if recording() and type(value) == "table" then
    -- Date a play when its threshold is reached, never before collection started.
    append("play", os.time(), value)
  end
end)

local function write_file(name, content)
  local path = nari.plugin.data .. "/" .. name
  local temporary = path .. ".tmp"
  local file = assert(io.open(temporary, "wb"))
  assert(file:write(content))
  assert(file:close())
  -- Lua's Windows rename cannot replace an existing file. Keep a previous export
  -- until the new file is complete; unique request suffixes avoid replacement.
  assert(os.rename(temporary, path))
  return path
end

nari.on("message", function(request)
  local ok, result = pcall(function()
    flush()
    if request.action == "summary" then
      local start, finish, label = model.period(request.year, request.month, request.mode)
      return { stats = archive:summary(start, finish), label = label, records = archive.state.total, files = #archive.state.pages }
    elseif request.action == "merge" then
      return { added = archive:import(request.payload) }
    elseif request.action == "export" then
      local paths = archive:export(function(index, content)
        return write_file("wrapped-history-" .. os.time() .. "-" .. request.request_id .. "-part" .. index .. ".json", content)
      end)
      return { paths = paths }
    elseif request.action == "card" then
      local start, finish, label = model.period(request.year, request.month, request.mode)
      local stats = archive:summary(start, finish)
      return { path = write_file("wrapped-card-" .. os.time() .. "-" .. request.request_id .. ".svg", model.card(stats, label)), stats = stats, label = label }
    elseif request.action == "pause" then
      nari.set("paused", request.paused == true)
      last_tick = os.time()
      return { paused = request.paused == true }
    end
    error("Unknown Wrapped request")
  end)
  nari.send({ type = "reply", request_id = request.request_id, result = ok and result or nil, error = not ok and tostring(result) or nil })
end)

local function heartbeat()
  flush()
  nari.after(60, heartbeat)
end
nari.after(60, heartbeat)

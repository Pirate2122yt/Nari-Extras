-- Immutable, bounded pages. Commit their index only after every file is safe.
-- A save replaces at most the final page; sealed pages are never rewritten.
local model = require("model")
local M = { PAGE_SIZE = 256 }
local Store = {}
Store.__index = Store

local function read_json(name, hash)
  assert(type(name) == "string" and name:match("^wrapped%-[%w-]+%.json$"), "Invalid history file name")
  local file = assert(io.open(nari.plugin.data .. "/" .. name, "rb"))
  local content = file:read("a")
  assert(file:close())
  assert(not hash or nari.sha256(content) == hash, "Damaged history file; restore a backup")
  return nari.json_decode(content)
end

local function write_json(name, value)
  local path = nari.plugin.data .. "/" .. name
  local temporary = path .. ".tmp"
  local file = assert(io.open(temporary, "wb"))
  local content = nari.json_encode(value)
  assert(file:write(content))
  assert(file:close())
  assert(os.rename(temporary, path)) -- Unique destination: safe on Windows too.
  return nari.sha256(content)
end

local function remove(name)
  pcall(os.remove, nari.plugin.data .. "/" .. name)
end

function M.payload(events)
  return #events == 0 and nari.json_decode('{"schema":1,"events":[]}') or { schema = model.SCHEMA, events = events }
end

function Store:events(page)
  local value = read_json(page.file, page.hash)
  assert(value.schema == 1 and type(value.events) == "table" and #value.events == page.count, "Damaged history page; restore a backup")
  return value.events
end

function Store:rollup(page)
  local ok, value = pcall(read_json, page.summary, page.summary_hash)
  if ok and type(value) == "table" and type(value.tracks) == "table" and type(value.days) == "table"
    and type(value.plays) == "number" and type(value.seconds) == "number" and model.calendar_valid(value) then return value end
  -- Summaries are disposable caches; raw records remain authoritative.
  return model.rollup(self:events(page))
end

function Store:write_page(events)
  local token = nari.sha256(nari.random_bytes(32)):sub(1, 32)
  local page = { file = "wrapped-page-" .. token .. ".json", summary = "wrapped-summary-" .. token .. ".json", count = #events, first = math.huge, finish = 0, ids = {} }
  for _, event in ipairs(events) do
    page.first = math.min(page.first, event.at)
    page.finish = math.max(page.finish, event.at + (event.seconds or 1))
    local device, number = event.id:match("^([^:]+):(%d+)$")
    number = tonumber(number)
    local range = page.ids[device] or { first = number, last = number }
    range.first, range.last = math.min(range.first, number), math.max(range.last, number)
    page.ids[device] = range
  end
  page.hash = write_json(page.file, M.payload(events))
  page.summary_hash = write_json(page.summary, model.rollup(events))
  return page
end

function Store:commit(events)
  if #events == 0 then return end
  local state = self.state
  local pages = {}
  for index, page in ipairs(state.pages) do pages[index] = page end
  local old, active = pages[#pages], {}
  if old and old.count < M.PAGE_SIZE then
    active = self:events(old)
    table.remove(pages)
  else old = nil end
  local sequence = state.seq
  for _, event in ipairs(events) do
    local device, number = event.id:match("^([^:]+):(%d+)$")
    if device == state.device then sequence = math.max(sequence, tonumber(number)) end
    active[#active + 1] = event
    if #active == M.PAGE_SIZE then
      pages[#pages + 1] = self:write_page(active)
      active = {}
    end
  end
  if #active > 0 then pages[#pages + 1] = self:write_page(active) end
  local next_state = { schema = 2, device = state.device, seq = sequence, total = state.total + #events, pages = pages }
  -- Native nari.set is atomic. Until it succeeds the previous index and all
  -- files it references remain intact. Failed writes can leave unused files.
  nari.set("archive", next_state)
  self.state = next_state
  if old then remove(old.file); remove(old.summary) end
end

function Store:append(kind, at, details, seconds)
  local event = model.track(details)
  event.id, event.kind, event.at, event.seconds = self.state.device .. ":" .. (self.state.seq + 1), kind, at, seconds
  self:commit({ model.validate(event) })
end

function Store:import(payload)
  -- Validate the entire import first; reject conflicts before writing anything.
  -- The text picker bounds one import's size; total history has no record cap.
  local wanted = model.merge({}, payload)
  local candidates = model.index(wanted)
  local ranges = {}
  for _, event in ipairs(wanted) do
    local device, number = event.id:match("^([^:]+):(%d+)$")
    number = tonumber(number)
    local range = ranges[device] or { first = number, last = number }
    range.first, range.last = math.min(range.first, number), math.max(range.last, number)
    ranges[device] = range
  end
  for _, page in ipairs(self.state.pages) do
    local overlaps = page.ids == nil
    for device, range in pairs(page.ids or {}) do
      local wanted_range = ranges[device]
      if wanted_range and range.first <= wanted_range.last and range.last >= wanted_range.first then overlaps = true; break end
    end
    if overlaps then
      for _, event in ipairs(self:events(page)) do
        if candidates[event.id] then
          model.merge({ event }, M.payload({ candidates[event.id] }))
          candidates[event.id] = nil
        end
      end
    end
  end
  local additions = {}
  for _, event in ipairs(wanted) do
    if candidates[event.id] then additions[#additions + 1] = event end
  end
  table.sort(additions, function(a, b) return a.at < b.at or (a.at == b.at and a.id < b.id) end)
  self:commit(additions)
  return #additions
end

function Store:summary(start, finish)
  local total = model.accumulator()
  for index, page in ipairs(self.state.pages) do
    if page.first < finish and page.finish > start then
      local part
      if page.first >= start and page.finish <= finish then part = self:rollup(page)
      else part = model.rollup(self:events(page), start, finish) end
      model.combine(total, part)
    end
  end
  -- Only retain first-listen dates for songs in the selected report. Stream
  -- older page summaries one by one rather than holding all history in RAM.
  if next(total.tracks) then
    for index, page in ipairs(self.state.pages) do
      if page.first < start then model.observe_firsts(total, self:rollup(page)) end
    end
  end
  return model.finish_summary(total, start)
end

function Store:export(write)
  local paths, part, bytes = {}, {}, 0
  local function flush()
    paths[#paths + 1] = write(#paths + 1, nari.json_encode(M.payload(part)))
    part, bytes = {}, 0
  end
  for _, page in ipairs(self.state.pages) do
    for _, event in ipairs(self:events(page)) do
      local size = #nari.json_encode(event) + 1
      if bytes + size > 1000000 and #part > 0 then flush() end
      part[#part + 1], bytes = event, bytes + size
    end
  end
  if #part > 0 or #paths == 0 then flush() end
  return paths
end

function M.open()
  local state = nari.get("archive")
  if state then
    assert(state.schema == 2 and type(state.device) == "string" and state.device:match("^[a-f0-9]+$") and #state.device == 32
      and type(state.pages) == "table" and type(state.seq) == "number" and type(state.total) == "number", "Invalid Wrapped archive; restore a backup")
    local total = 0
    for _, page in ipairs(state.pages) do
      assert(type(page.count) == "number" and page.count >= 1 and page.count <= M.PAGE_SIZE, "Invalid history page")
      total = total + page.count
    end
    assert(total == state.total, "Incomplete Wrapped archive; restore a backup")
    return setmetatable({ state = state }, Store)
  end
  local legacy = nari.get("journal")
  local events, device = {}, nari.sha256(nari.random_bytes(32)):sub(1, 32)
  if legacy then
    assert(type(legacy) == "table" and type(legacy.device) == "string" and legacy.device:match("^[a-f0-9]+$") and #legacy.device == 32,
      "Invalid Wrapped journal; restore a backup before continuing")
    events, device = model.merge({}, legacy), legacy.device
    table.sort(events, function(a, b) return a.at < b.at or (a.at == b.at and a.id < b.id) end)
  end
  local sequence = legacy and legacy.seq or 0
  assert(type(sequence) == "number" and sequence >= 0 and sequence == math.floor(sequence), "Invalid record counter")
  local store = setmetatable({ state = { schema = 2, device = device, seq = sequence, total = 0, pages = {} } }, Store)
  -- Complete the conversion before removing the old journal. On interruption
  -- the old journal remains readable and conversion can safely be retried.
  if #events > 0 then store:commit(events) else nari.set("archive", store.state) end
  if legacy then nari.set("journal", nil) end
  return store
end

return M

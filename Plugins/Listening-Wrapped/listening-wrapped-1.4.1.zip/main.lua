local ICON = "icon.svg"
local card = require("card")
local downloads = require("downloads")
local dashboard = require("dashboard")
local today = os.date("*t")
local year, month, mode = today.year, today.month, "month"
local worker = nari.thread("collector.lua")
local pending, request_id, views = {}, 0, {}
local popups = {}
local latest_summary
local enabled = true

local function style_popup(dialog)
  -- These controls belong to this plugin-created dialog, not Nari's other pages.
  local body = dialog.content:get_parent()
  local panel = body:get_parent()
  panel.padding, panel.corner_radius = 32, 24
  panel.use_custom_colors = true
  panel.custom_bg_color, panel.custom_gradient_color = Color("#140e17"), Color("#321420")
  body:add_theme_constant_override("separation", 16)
  dialog.footer.alignment = 2
  for _, control in ipairs(dialog.footer:get_children()) do
    control.font_size, control.padding, control.corner_radius = 32, 12, 16
    control.custom_minimum_size = Vector2(160, 72)
    control.size_flags_horizontal = 0
    control.use_custom_colors = true
    control.custom_bg_color, control.custom_gradient_color = Color("#40202d"), Color("#70263b")
    control.custom_fg_color = Color("#fff5f7")
  end
end

local function popup(dialog)
  style_popup(dialog)
  dialog:popup()
  local window = dialog:get_window()
  local viewport = dialog:get_viewport()
  local closing = false
  popups[dialog] = true
  -- Escape is not consistently mapped to Nari's custom "back" action. Handle
  -- the physical key explicitly, and only for the frontmost Wrapped popup.
  local disconnect = window.window_input:connect(function(event)
    if closing or Main:input_root() ~= dialog then return end
    if not event:is_class("InputEventKey") or not event.pressed or event.echo then return end
    local escape = 4194305 -- Godot Key.ESCAPE (global enums aren't exposed in Lua).
    if event.keycode ~= escape and event.physical_keycode ~= escape then return end
    closing = true
    -- Consume it in both the native window and the content viewport so one
    -- key press cannot also navigate the underlying page back to Home.
    window:set_input_as_handled()
    viewport:set_input_as_handled()
    dialog:close()
  end)
  local function cleanup()
    disconnect()
    popups[dialog] = nil
  end
  dialog.closed:connect(cleanup)
  dialog.tree_exiting:connect(cleanup)
end

local function request(action, values, callback)
  request_id = request_id + 1
  local message = values or {}
  message.action, message.request_id = action, request_id
  if callback then pending[request_id] = callback end
  worker:send(message)
end

worker:on_message(function(message)
  if message.type == "error" then
    Snackbar.post("Listening Wrapped", message.message)
  elseif message.type == "reply" then
    local callback = pending[message.request_id]
    pending[message.request_id] = nil
    if message.error then Snackbar.post("Wrapped couldn't finish", message.error) end
    if callback then callback(message.result, message.error) end
  end
end)
worker:on_error(function(problem)
  pending = {}
  Snackbar.post("Wrapped collector stopped", tostring(problem))
end)

local function label(parent, text, size)
  local control = NariLabel.new()
  control.text, control.font_size, control.autowrap_mode = text, size or 22, 3
  control.use_custom_color, control.custom_color = true, Color("#fff5f7")
  parent:add_child(control)
  return control
end

local function menu(title, subtitle)
  local dialog = Dialog.new()
  dialog.content:add_theme_constant_override("separation", 10)
  label(dialog.content, title, 30)
  if subtitle and subtitle ~= "" then label(dialog.content, subtitle, 20) end
  return dialog
end

local function option(dialog, text, action)
  local control = dialog:add_option(text, action)
  control.font_size, control.padding, control.corner_radius = 22, 10, 12
  control.custom_minimum_size = Vector2(0, 48)
  return control
end

local function refresh()
  local asked_year, asked_month, asked_mode = year, month, mode
  request("summary", { year = year, month = month, mode = mode }, function(result)
    if not result or year ~= asked_year or month ~= asked_month or mode ~= asked_mode then return end
    result.mode = asked_mode
    latest_summary = result
    for view in pairs(views) do
      view:update(result)
    end
  end)
end

local function current_period(which)
  today = os.date("*t")
  year, month, mode = today.year, today.month, which
  refresh()
end

local function move_period(step)
  if mode == "year" then year = math.max(1970, math.min(3000, year + step))
  else
    local index = math.max(1970 * 12, math.min(3000 * 12 + 11, year * 12 + month - 1 + step))
    year, month = math.floor(index / 12), index % 12 + 1
  end
  refresh()
end

local function period_menu()
  local dialog = menu("Pick a period")
  option(dialog, "This month", function() current_period("month") end)
  option(dialog, "This year", function() current_period("year") end)
  option(dialog, "Previous period", function() move_period(-1) end)
  option(dialog, "Next period", function() move_period(1) end)
  dialog:add_button("Cancel")
  popup(dialog)
end

local function saved_file(paths)
  local dialog = menu("Your export is ready", #paths == 1 and paths[1]:match("[^/\\]+$") or #paths .. " backup files")
  local status = label(dialog.content, "Save a copy to Downloads/Nari/Wrapped so you can find it in your Files app.", 32)
  local function action_button(text, action)
    local control = NariButton.new()
    control.text, control.font_size, control.custom_minimum_size = text, 36, Vector2(0, 88)
    control.autowrap_mode, control.clip_text, control.text_overrun_behavior = 0, true, 3
    control.focus_mode, control.mouse_filter = 2, 1
    control.pressed:connect(action)
    dialog.content:add_child(control)
    return control
  end
  local alive, copied, remaining = true, 0, paths
  local function error_detail(problem)
    -- Show the underlying failure instead of hiding it behind a retry message.
    return tostring(problem):match("^[^\r\n]+") or "Unknown saving error"
  end
  local save, open
  save = action_button("Save to Downloads", function()
    if save.disabled then return end
    save.disabled = true
    local total = #remaining
    status.text = "Saving copies to Downloads…"
    local ok, started, problem = pcall(downloads.save, remaining, function(count)
      if alive and enabled then status.text = "Saved " .. count .. " of " .. total .. " files…" end
    end, function(result)
      if not enabled then return end
      copied, remaining = copied + result.copied, result.remaining
      if alive then
        open.visible = copied > 0
        save.disabled = #remaining == 0
        save.text = #remaining > 0 and "Retry remaining files" or "Saved to Downloads"
        status.text = result.error and (copied .. " file(s) saved.\n" .. error_detail(result.error):gsub("^.-:%d+:%s*", "") .. "\nOriginal exports are safe. Tap Retry to try again.")
          or (copied .. " file(s) saved to " .. result.location .. ".")
      end
      if result.error then
        nari.warn("Wrapped download copy: " .. result.error)
        Snackbar.post("Couldn't finish saving", "The reason is shown in the export window. Your original exports are safe.")
      else Snackbar.post("Saved to Downloads", result.location) end
    end)
    if not ok or not started then
      save.disabled = false
      status.text = "Couldn't start saving.\n" .. error_detail(ok and problem or started):gsub("^.-:%d+:%s*", "") .. "\nCheck that All access is allowed for Wrapped."
    end
  end)
  open = action_button("Open Downloads", function()
    local ok = pcall(downloads.open_folder)
    if not ok then Snackbar.post("Open your Files app", "Look in Downloads → Nari → Wrapped.") end
  end)
  open.visible = false
  local function cleanup() alive = false end
  dialog.closed:connect(cleanup)
  dialog.tree_exiting:connect(cleanup)
  dialog:add_button("Close")
  popup(dialog)
end

local function export_history()
  request("export", nil, function(result) if result then saved_file(result.paths) end end)
end

local function import_history()
  nari.await(Plugins:pick_text({ "json" }), function(text)
    if text == "" then return end
    local ok, payload = pcall(nari.json_decode, text)
    if not ok then Snackbar.post("Couldn't import", "Choose a Wrapped history JSON file."); return end
    request("merge", { payload = payload }, function(result)
      if result then Snackbar.post("History merged", result.added .. " new records; duplicates skipped."); refresh() end
    end)
  end)
end

local function export_card()
  request("card", { year = year, month = month, mode = mode }, function(result)
    if not result then return end
    card.save(Main, result.stats, result.label, result.path:gsub("%.svg$", ".png"), function(png)
      saved_file({ png or result.path })
    end)
  end)
end

local function more_menu()
  local dialog = menu("Wrapped tools")
  option(dialog, "Save share card", export_card)
  option(dialog, "Refresh stats", refresh)
  option(dialog, "Export history", export_history)
  option(dialog, "Import history", import_history)
  option(dialog, "Choose period", period_menu)
  option(dialog, "About Wrapped", function()
    local info = menu("About your Wrapped")
    label(info.content, "Minutes are approximate active-playback time. A play counts after half a song or four minutes, for tracks at least 30 seconds long. Periods use this device's time zone.", 20)
    label(info.content, "Tracking starts when Wrapped is enabled. Share cards contain only the selected summary; history exports contain song details and timestamps.", 20)
    label(info.content, (latest_summary and latest_summary.records or 0) .. " saved records", 18)
    info:add_button("Close")
    popup(info)
  end)
  dialog:add_button("Close")
  popup(dialog)
end

local function build(parent)
  local view = dashboard.build(parent, {
    previous = function() move_period(-1) end,
    next = function() move_period(1) end,
    month = function() current_period("month") end,
    year = function() current_period("year") end,
    share = export_card,
    more = more_menu,
  })
  views[view] = true
  parent.tree_exiting:connect(function()
    views[view] = nil
    view.cleanup()
  end)
  refresh()
  return view
end

local function open_wrapped()
  local dialog = Dialog.new()
  dialog.dismissable = false
  local area = MarginContainer.new()
  area.name = "WrappedArea"
  dialog.content:add_child(area)
  local viewport = Main:input_root():get_viewport()
  local panel = dialog.content:get_parent():get_parent()
  local alive, queued, desired_width = true, false, 0
  local function fit()
    if not alive then return end
    local screen = viewport:get_visible_rect().size
    desired_width = math.max(240, screen.x * 0.94)
    panel.custom_minimum_size = Vector2(desired_width, 0)
    -- Size in canvas-relative units: fixed pixel caps made the popup tiny on
    -- Nari's high-resolution desktop canvas. Leave space for padding/footer.
    area.custom_minimum_size = Vector2(0, math.max(120, screen.y * 0.92 - 156))
  end
  fit()
  build(area)
  dialog:add_button("Close")
  popup(dialog)
  viewport = dialog:get_viewport()
  fit()
  local function schedule_fit()
    if not alive or queued then return end
    queued = true
    nari.after(0, function() queued = false; fit() end)
  end
  local unresize = viewport.size_changed:connect(schedule_fit)
  -- Dialog normally restores an 880px minimum when its backdrop resizes. Keep
  -- this owned dashboard wide, after Nari has completed its layout pass.
  local unminimum = panel.minimum_size_changed:connect(function()
    if panel.custom_minimum_size.x ~= desired_width then schedule_fit() end
  end)
  local function cleanup()
    alive = false
    unresize()
    unminimum()
  end
  dialog.closed:connect(cleanup)
  dialog.tree_exiting:connect(cleanup)
  schedule_fit()
end

nari.home_entry({ title = "Listening Wrapped", subtitle = "Your month in music", icon = ICON, color = "Red", action = open_wrapped })
nari.now_playing_tab({ id = "wrapped", title = "Wrapped", icon = ICON, build = build })
nari.settings(function() return {
  { title = "Open Wrapped", icon = ICON, action = open_wrapped },
  { title = "Collect listening history", description = "Turning this off pauses new records.", value = function() return nari.get("paused") and "Off" or "On" end,
    action = function() request("pause", { paused = nari.get("paused") ~= true }) end },
  { title = "Export history", icon = ICON, action = export_history },
  { title = "Import history", icon = ICON, action = import_history },
} end)
nari.on("disable", function()
  enabled = false
  downloads.cancel()
  for dialog in pairs(popups) do dialog:close() end
  pending, views = {}, {}
end)

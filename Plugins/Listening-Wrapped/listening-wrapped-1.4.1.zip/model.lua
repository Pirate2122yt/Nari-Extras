-- Pure data functions shared by the background collector, UI, and tests.
local M = { SCHEMA = 1 }

local function integer(value, minimum, maximum)
  return type(value) == "number" and value == math.floor(value)
    and value >= minimum and value <= maximum
end

local function text(value, fallback)
  if type(value) ~= "string" or not utf8.len(value) then return fallback end
  value = value:gsub("[%z\1-\8\11\12\14-\31]", "")
  if #value > 512 then
    local length = 512
    while length > 0 and not utf8.len(value:sub(1, length)) do length = length - 1 end
    value = value:sub(1, length)
  end
  return value ~= "" and value or fallback
end

function M.track(song)
  return {
    title = text(song.title, "Unknown song"),
    artist = text(song.artist, "Unknown artist"),
    album = text(song.album, "Unknown album"),
  }
end

local function normalized(value)
  return value:lower():gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", " ")
end

function M.track_key(event)
  -- Length prefixes avoid ambiguous separators in song/artist names.
  local parts = {}
  for _, value in ipairs({ event.artist, event.title, event.album }) do
    value = normalized(value)
    table.insert(parts, #value .. ":" .. value)
  end
  return table.concat(parts)
end

function M.validate(event)
  assert(type(event) == "table", "Invalid history record")
  assert(type(event.id) == "string" and #event.id <= 100 and event.id:match("^[%w_-]+:%d+$"), "Invalid record ID")
  assert(integer(tonumber(event.id:match(":(%d+)$")), 1, 1000000000000), "Invalid record counter")
  assert(event.kind == "play" or event.kind == "time", "Invalid record kind")
  assert(integer(event.at, 0, 40000000000), "Invalid record timestamp")
  for _, key in ipairs({ "title", "artist", "album" }) do
    assert(type(event[key]) == "string" and #event[key] <= 512 and #event[key] > 0 and utf8.len(event[key]), "Invalid song details")
  end
  local clean = M.track(event)
  clean.id, clean.kind, clean.at = event.id, event.kind, event.at
  if event.kind == "time" then
    assert(integer(event.seconds, 1, 120), "Invalid listening interval")
    clean.seconds = event.seconds
  end
  return clean
end

local function equal(a, b)
  for _, key in ipairs({ "id", "kind", "at", "title", "artist", "album", "seconds" }) do
    if a[key] ~= b[key] then return false end
  end
  return true
end

function M.index(events)
  local by_id = {}
  for _, event in ipairs(events) do by_id[event.id] = event end
  return by_id
end

function M.merge(existing, payload)
  assert(type(payload) == "table" and payload.schema == M.SCHEMA and type(payload.events) == "table", "Not a Listening Wrapped history file")
  for key in pairs(payload.events) do
    assert(integer(key, 1, #payload.events), "History must contain a list of records")
  end
  local index, additions = M.index(existing), {}
  for _, raw in ipairs(payload.events) do
    local event = M.validate(raw)
    if index[event.id] then
      assert(equal(index[event.id], event), "Conflicting record ID; no changes were imported")
    else
      index[event.id] = event
      table.insert(additions, event)
    end
  end
  -- Validate everything before changing the caller's journal.
  local merged = {}
  for _, event in ipairs(existing) do table.insert(merged, event) end
  for _, event in ipairs(additions) do table.insert(merged, event) end
  return merged, #additions
end

function M.period(year, month, mode)
  assert(integer(year, 1970, 3000) and integer(month, 1, 12), "Invalid period")
  local first = mode == "year" and 1 or month
  local start = os.time({ year = year, month = first, day = 1, hour = 0 })
  local finish = os.time({ year = mode == "year" and year + 1 or year, month = mode == "year" and 1 or month + 1, day = 1, hour = 0 })
  return start, finish, mode == "year" and tostring(year) or os.date("%B %Y", start)
end

local function sorted(groups)
  local list = {}
  for _, entry in pairs(groups) do table.insert(list, entry) end
  table.sort(list, function(a, b)
    if a.plays ~= b.plays then return a.plays > b.plays end
    if a.seconds ~= b.seconds then return a.seconds > b.seconds end
    return a.name < b.name
  end)
  return list
end

-- Page summaries retain totals per song and active days, instead of every tick.
-- Raw pages remain on disk for exact boundary queries and backup restoration.
function M.accumulator()
  return { tracks = {}, days = {}, seconds = 0, plays = 0 }
end

local function midnight(year, month, day)
  local ok, value = pcall(os.time, { year = year, month = month, day = day, hour = 0, min = 0, sec = 0 })
  if ok then return value end
  -- The first UTC timestamps can fall on 1969-12-31 locally. Windows cannot
  -- construct that midnight directly; derive it from the following day.
  assert(year == 1969 and month == 12 and day == 31, value)
  return os.time({ year = 1970, month = 1, day = 1, hour = 0, min = 0, sec = 0 }) - 86400
end

local function add_day(days, at)
  local date = os.date("*t", at)
  local key = os.date("%Y-%m-%d", at)
  if not days[key] then
    days[key] = { start = midnight(date.year, date.month, date.day), finish = midnight(date.year, date.month, date.day + 1) }
  end
  return days[key].finish
end

function M.rollup(events, start, finish)
  start, finish = start or 0, finish or math.huge
  local result = M.accumulator()
  for _, event in ipairs(events) do
    local key = M.track_key(event)
    local track = result.tracks[key]
    if not track then
      track = { title = event.title, artist = event.artist, album = event.album, first = event.at, plays = 0, seconds = 0 }
      result.tracks[key] = track
    end
    track.first = math.min(track.first, event.at)
    local plays = event.kind == "play" and event.at >= start and event.at < finish and 1 or 0
    local seconds = event.kind == "time" and math.max(0, math.min(event.at + event.seconds, finish) - math.max(event.at, start)) or 0
    if plays > 0 or seconds > 0 then
      if track.plays == 0 and track.seconds == 0 then
        track.title, track.artist, track.album = event.title, event.artist, event.album
      end
      track.plays, track.seconds = track.plays + plays, track.seconds + seconds
      result.plays, result.seconds = result.plays + plays, result.seconds + seconds
      if plays > 0 then add_day(result.days, event.at) end
      local at, last = math.max(event.at, start), math.min(event.at + (event.seconds or 0), finish)
      while at < last do at = add_day(result.days, at) end
    end
  end
  return result
end

function M.calendar_valid(summary)
  -- Rebuild from raw records after a timezone change, including DST changes.
  for key, bounds in pairs(summary.days) do
    local year, month, day = key:match("^(%d+)%-(%d+)%-(%d+)$")
    if midnight(tonumber(year), tonumber(month), tonumber(day)) ~= bounds.start
      or midnight(tonumber(year), tonumber(month), tonumber(day) + 1) ~= bounds.finish then return false end
  end
  return true
end

function M.combine(result, summary)
  result.plays, result.seconds = result.plays + summary.plays, result.seconds + summary.seconds
  for day, bounds in pairs(summary.days) do result.days[day] = bounds end
  for key, entry in pairs(summary.tracks) do
    if entry.plays > 0 or entry.seconds > 0 then
      local target = result.tracks[key]
      if not target then
        target = { title = entry.title, artist = entry.artist, album = entry.album, first = entry.first, plays = 0, seconds = 0 }
        result.tracks[key] = target
      end
      target.plays, target.seconds = target.plays + entry.plays, target.seconds + entry.seconds
      target.first = math.min(target.first, entry.first)
    end
  end
end

function M.observe_firsts(result, summary)
  for key, entry in pairs(summary.tracks) do
    local target = result.tracks[key]
    if target then target.first = math.min(target.first, entry.first) end
  end
end

function M.finish_summary(total, start)
  local result = { seconds = total.seconds, plays = total.plays, unique_tracks = 0, new_tracks = 0, days = 0, streak = 0 }
  local tracks, artists, albums = {}, {}, {}
  local function add(groups, key, name, plays, seconds, subtitle)
    local entry = groups[key] or { name = name, subtitle = subtitle, plays = 0, seconds = 0 }
    entry.plays, entry.seconds = entry.plays + plays, entry.seconds + seconds
    groups[key] = entry
  end
  for key, track in pairs(total.tracks) do
    if track.plays > 0 or track.seconds > 0 then
      add(tracks, key, track.title, track.plays, track.seconds, track.artist)
      add(artists, normalized(track.artist), track.artist, track.plays, track.seconds)
      add(albums, normalized(track.artist) .. "\0" .. normalized(track.album), track.album, track.plays, track.seconds, track.artist)
      if track.plays > 0 then
        result.unique_tracks = result.unique_tracks + 1
        if track.first >= start then result.new_tracks = result.new_tracks + 1 end
      end
    end
  end
  local ordered_days = {}
  for day in pairs(total.days) do table.insert(ordered_days, day) end
  table.sort(ordered_days)
  local run, previous = 0, nil
  for _, day in ipairs(ordered_days) do
    local year, month, date = day:match("(%d+)%-(%d+)%-(%d+)")
    year, month, date = tonumber(year), tonumber(month), tonumber(date)
    local prior_year = year - 1
    local ordinal = prior_year * 365 + math.floor(prior_year / 4) - math.floor(prior_year / 100) + math.floor(prior_year / 400) + date
    local lengths = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
    if year % 4 == 0 and (year % 100 ~= 0 or year % 400 == 0) then lengths[2] = 29 end
    for index = 1, month - 1 do ordinal = ordinal + lengths[index] end
    local consecutive = previous and ordinal == previous + 1
    run, previous = consecutive and run + 1 or 1, ordinal
    result.streak = math.max(result.streak, run)
  end
  result.days = #ordered_days
  result.tracks, result.artists, result.albums = sorted(tracks), sorted(artists), sorted(albums)
  return result
end

function M.summary(events, start, finish)
  return M.finish_summary(M.rollup(events, start, finish), start)
end

function M.xml(value)
  return tostring(value):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"):gsub('"', "&quot;"):gsub("'", "&apos;")
end

local function short(value, limit)
  if utf8.len(value) and utf8.len(value) > limit then return value:sub(1, utf8.offset(value, limit + 1) - 1) .. "…" end
  return value
end

function M.card(stats, period)
  local output = { '<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350"><defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="#250b22"/><stop offset="1" stop-color="#090c1c"/></linearGradient><linearGradient id="accent"><stop stop-color="#fa496b"/><stop offset="1" stop-color="#bb8aff"/></linearGradient></defs><rect width="1080" height="1350" rx="48" fill="url(#bg)"/><circle cx="1020" cy="40" r="300" fill="#74214f" opacity="0.25"/><g font-family="Arial, Helvetica, sans-serif" fill="#ffffff">' }
  local function line(x, y, size, value, color)
    table.insert(output, string.format('<text x="%d" y="%d" font-size="%d" font-weight="%d" fill="%s">%s</text>', x, y, size, size >= 28 and 600 or 400, color or "#ffffff", M.xml(value)))
  end
  line(70, 100, 26, "LISTENING WRAPPED", "#ff8ca8")
  line(70, 180, 60, period)
  line(70, 290, 92, math.floor(stats.seconds / 60))
  line(70, 335, 26, "minutes of music", "#ccbed8")
  line(580, 290, 92, stats.plays)
  line(580, 335, 26, "counted plays", "#ccbed8")
  line(70, 405, 25, stats.unique_tracks .. " songs  •  " .. stats.days .. " days  •  " .. stats.streak .. "-day streak")
  line(70, 490, 34, "Your top artists")
  local maximum = stats.artists[1] and math.max(stats.artists[1].plays, 1) or 1
  for index = 1, math.min(3, #stats.artists) do
    local artist, y = stats.artists[index], 550 + (index - 1) * 115
    line(70, y, 30, index .. ". " .. short(artist.name, 34))
    line(900, y, 28, artist.plays)
    table.insert(output, string.format('<rect x="70" y="%d" width="%d" height="12" rx="6" fill="url(#accent)"/>', y + 24, math.max(12, math.floor(880 * artist.plays / maximum))))
  end
  line(70, 935, 34, "On repeat")
  local top = stats.tracks[1]
  line(70, 1000, 38, top and short(top.name, 36) or "Your story starts here")
  line(70, 1045, 28, top and short(top.subtitle, 46) or "Listen with Wrapped enabled.", "#ccbed8")
  line(70, 1120, 26, stats.new_tracks .. " songs new to your Wrapped")
  line(70, 1230, 21, "Approximate time tracked while playback is active.", "#b6a8c0")
  line(70, 1270, 21, "Nari  •  By Pirate2122yt", "#b6a8c0")
  table.insert(output, "</g></svg>")
  return table.concat(output)
end

return M

-- Copy explicit exports to public Downloads. Android uses MediaStore, so
-- scoped storage works without requesting Android's storage-management access.
-- Nari's All access permission is required for its Java and filesystem bridge.
local M = {}
local active
local CHUNK = 256 * 1024

local function source_name(path)
  assert(type(path) == "string", "Invalid export path")
  local root = nari.plugin.data:gsub("\\", "/"):gsub("/+$", "") .. "/"
  local normalized = path:gsub("\\", "/")
  assert(normalized:sub(1, #root) == root, "Choose a Wrapped export")
  local name = normalized:sub(#root + 1)
  assert(not name:find("/", 1, true) and not name:find("%z") and not name:find("..", 1, true), "Invalid export name")
  assert(name:match("^wrapped%-history%-.+%.json$") or name:match("^wrapped%-card%-.+%.png$") or name:match("^wrapped%-card%-.+%.svg$"), "Choose a Wrapped export")
  return name
end

local function java(target, method, ...)
  assert(target, "Android file service is unavailable")
  -- Java methods are dynamic; Object.call preserves their overloads and nil
  -- arguments through Nari's Godot/Lua bridge (requires All access).
  local value = target:call(method, ...)
  local problem = JavaClassWrapper:get_exception()
  if problem then error("Android could not complete " .. method) end
  return value
end

local function android_backend()
  local runtime = Engine:get_singleton("AndroidRuntime")
  assert(runtime, "Android file service is unavailable")
  local version = JavaClassWrapper:wrap("android.os.Build$VERSION")
  assert(version.SDK_INT >= 29, "Saving directly to Downloads requires Android 10 or newer")
  local context = java(runtime, "getApplicationContext")
  local resolver = java(context, "getContentResolver")
  local Values = JavaClassWrapper:wrap("android.content.ContentValues")
  local Downloads = JavaClassWrapper:wrap("android.provider.MediaStore$Downloads")
  local Input = JavaClassWrapper:wrap("java.io.FileInputStream")
  local Channels = JavaClassWrapper:wrap("java.nio.channels.Channels")
  local collection = java(Downloads, "getContentUri", "external_primary")
  local backend = { location = "Downloads/Nari/Wrapped" }
  function backend.begin(path)
    local state = { position = 0 }
    function state.abort()
      if state.output then pcall(java, state.output, "close"); state.output = nil end
      if state.input then pcall(java, state.input, "close"); state.input = nil end
      if state.uri then pcall(java, resolver, "delete", state.uri, nil, nil); state.uri = nil end
    end
    local ok, problem = pcall(function()
      local name = source_name(path)
      local mime = name:match("%.json$") and "application/json" or name:match("%.png$") and "image/png" or "image/svg+xml"
      state.input = assert(java(Input, "FileInputStream", path), "Couldn't read the export")
      state.channel = assert(java(state.input, "getChannel"), "Couldn't read the export")
      state.size = java(state.channel, "size")
      local values = java(Values, "ContentValues")
      java(values, "put", "_display_name", name)
      java(values, "put", "mime_type", mime)
      java(values, "put", "relative_path", "Download/Nari/Wrapped/")
      -- String values select ContentValues.put(String, String) unambiguously.
      -- MediaStore reads this numeric column with ContentValues.getAsInteger.
      java(values, "put", "is_pending", "1")
      state.uri = assert(java(resolver, "insert", collection, values), "Couldn't create a download")
      state.output = assert(java(resolver, "openOutputStream", state.uri, "w"), "Couldn't open the download")
      state.destination = assert(java(Channels, "newChannel", state.output), "Couldn't open the download")
    end)
    if not ok then state.abort(); error(problem) end
    function state.step()
      if state.position >= state.size then return true end
      local count = java(state.channel, "transferTo", state.position, math.min(CHUNK, state.size - state.position), state.destination)
      assert(type(count) == "number" and count > 0, "The download stopped before it was complete")
      state.position = state.position + count
      return state.position >= state.size
    end
    function state.finish()
      java(state.output, "close"); state.output = nil
      java(state.input, "close"); state.input = nil
      local values = java(Values, "ContentValues")
      java(values, "put", "is_pending", "0")
      assert(java(resolver, "update", state.uri, values, nil, nil) == 1, "Couldn't publish the download")
      -- Never overwrite a public file: each insert creates a new media entry.
      state.uri = nil
    end
    return state
  end
  return backend
end

local function desktop_backend()
  local root = OS:get_system_dir(3) -- OS.SYSTEM_DIR_DOWNLOADS
  assert(type(root) == "string" and root ~= "", "Your Downloads folder is unavailable")
  local folder = root:gsub("\\", "/"):gsub("/+$", "") .. "/Nari/Wrapped"
  assert(DirAccess.make_dir_recursive_absolute(folder) == 0, "Couldn't create the Downloads folder")
  local backend = { location = folder }
  function backend.begin(path)
    local name = source_name(path)
    local temporary = folder .. "/.wrapped-" .. nari.sha256(nari.random_bytes(32)):sub(1, 24) .. ".part"
    local state = {}
    function state.abort()
      if state.output then pcall(function() state.output:close() end); state.output = nil end
      if state.input then pcall(function() state.input:close() end); state.input = nil end
      pcall(os.remove, temporary)
    end
    local ok, problem = pcall(function()
      state.input = assert(io.open(path, "rb"))
      state.output = assert(io.open(temporary, "wb"))
    end)
    if not ok then state.abort(); error(problem) end
    function state.step()
      local bytes = state.input:read(CHUNK)
      if not bytes or bytes == "" then return true end
      assert(state.output:write(bytes))
      return false
    end
    function state.finish()
      assert(state.output:close()); state.output = nil
      assert(state.input:close()); state.input = nil
      local destination, suffix = folder .. "/" .. name, 1
      while FileAccess.file_exists(destination) do
        destination = folder .. "/" .. name:gsub("(%.[^.]+)$", " (" .. suffix .. ")%1")
        suffix = suffix + 1
      end
      assert(os.rename(temporary, destination))
    end
    return state
  end
  return backend
end

function M.save(paths, progress, done)
  if active then return false, "Another download is already being saved." end
  assert(type(paths) == "table" and #paths > 0, "No exports to copy")
  local files = {}
  for index, path in ipairs(paths) do source_name(path); files[index] = path end
  local job = { index = 1, copied = 0 }
  active = job
  local function finish(problem)
    if active ~= job then return end
    if job.file then job.file.abort(); job.file = nil end
    active = nil
    local remaining = {}
    for index = job.index, #files do remaining[#remaining + 1] = files[index] end
    done({ copied = job.copied, remaining = remaining, location = job.backend and job.backend.location or "Downloads/Nari/Wrapped", error = problem })
  end
  job.cancel = function() finish("Download cancelled. Original exports are still saved.") end
  local step
  step = function()
    if active ~= job then return end
    local ok, problem = pcall(function()
      if not job.backend then job.backend = OS:get_name() == "Android" and android_backend() or desktop_backend() end
      if not job.file then job.file = job.backend.begin(files[job.index]) end
      if job.file.step() then
        job.file.finish(); job.file = nil
        job.copied, job.index = job.copied + 1, job.index + 1
        if progress then progress(job.copied, #files) end
        if job.index > #files then finish(); return end
      end
      nari.after(0, step)
    end)
    if not ok then finish(tostring(problem)) end
  end
  nari.after(0, step)
  return true
end

function M.open_folder()
  if OS:get_name() == "Android" then
    local runtime = Engine:get_singleton("AndroidRuntime")
    local Intent = JavaClassWrapper:wrap("android.content.Intent")
    local intent = java(Intent, "Intent")
    java(intent, "setAction", "android.intent.action.VIEW_DOWNLOADS")
    java(java(runtime, "getActivity"), "startActivity", intent)
  else
    local folder = OS:get_system_dir(3):gsub("\\", "/"):gsub("/+$", "") .. "/Nari/Wrapped"
    assert(OS:shell_open(folder) == 0, "Couldn't open Downloads")
  end
end

function M.cancel() if active then active.cancel() end end
return M

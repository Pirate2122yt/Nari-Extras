# Listening Wrapped

Your month or year in music: top songs, artists, albums, listening minutes, active days and streaks. Compatible with **Nari 1.2**.

## Setup

1. Install `listening-wrapped-1.4.2.zip` through **Settings → Plugins → Install plugin**.
2. Allow **All access**, then enable it. This broad permission is needed to save copies to Downloads; Wrapped stays offline.
3. Open **Home → Listening Wrapped** or **Now Playing → Wrapped**.

Choose **This month** or **This year**, and use the arrows to browse. **More…** includes refresh, history import/export and help. Close with **Close** or **Escape**; swipe inside the report to scroll on phones.

## Backups and cards

Use **Save card** for a summary image or **More → Export history** for a JSON backup. Then tap **Save to Downloads** to copy it to **Downloads → Nari → Wrapped**. Direct Android Downloads saving requires **Android 10+**.

Restore with **Import history**. Import every part of a multi-file backup; duplicate records are skipped. Updating keeps your history. **Back up before uninstalling**, which deletes the plugin's local data.

## How counting works

Tracking starts when enabled; earlier listening cannot be recovered. Minutes approximate active playback. Plays count after half a song or four minutes, for songs at least 30 seconds long. Closing Nari can lose the latest unsaved minute.

History stays on your device with no fixed record cap, subject to available storage. Pause collection in the plugin's settings.

By Pirate2122yt

# Listening Wrapped

Your month or year in music: top songs, artists and albums, approximate listening minutes, active days, streaks, and songs new to your Wrapped.

## Get started

1. Install `listening-wrapped-1.3.1.zip` in **Settings → Plugins → Install plugin**, then enable it.
2. Listen normally, using any music source.
3. Open **Home → Listening Wrapped** or **Now Playing → Wrapped**.
4. Use **This month**, **This year**, and the arrow buttons to browse periods. **Save card** exports a PNG, with an SVG fallback.

The desktop dashboard fills about 94% of the window width and 92% of its height, with larger text and controls. It shows stat tiles and three ranking columns and adapts to smaller windows. **More…** contains history import/export, refresh and help. Save card is also available there on narrow screens.

Scroll inside the report to see the rest. On phones, swipe anywhere on the stats, text or ranking cards to scroll. Close it with **Close** or **Escape**. Escape closes the frontmost Wrapped popup first, so leaving the period picker keeps the report open. Updating the plugin keeps your collected history.

Tracking starts when the plugin is enabled. It cannot recreate earlier months from Nari's built-in history. It keeps working with the screen off while Nari and its audio service are running. You can pause collection in the plugin's settings.

Minutes measure approximate time with playback active, including partial songs; they are not the sum of song lengths. Seeking does not add minutes. Plays follow Nari's rule: half a song or four minutes, for tracks at least 30 seconds long. The collector saves at most once a minute during continuous playback; closing the app or disabling the plugin can lose up to the most recent minute. Device sleep, buffering, casting, clock changes and speed effects can affect the time estimate. Periods use the viewing device's time zone. Artist collaborations use the credited artist field. Songs match across sources by normalized title, artist and album, so different metadata can split the same song.

## Backups and saved files

Use **Export history** to save a JSON backup and **Import history** to restore it. Import every part if a backup contains several files. Reimporting the same records does not increase the counts. Exports and cards go to the plugin's data folder; the saved-file dialog shows the path. On Android, access to this app-private folder depends on the device.

## Your data

Wrapped runs entirely on your device and requires no permissions. History backups include song titles, credited artists, albums, timestamps, approximate listening intervals and record IDs. Saved cards include only the selected summary. Export a backup before uninstalling: uninstalling deletes the local history.

History has no fixed record limit. It is stored in small files of up to 256 records, with compact song totals and active-day summaries for reports. Saving updates only the latest small file and its index. Older detailed records remain on disk for backups and exact date boundaries; they are never automatically deleted. Reports read page summaries one at a time, and backups are exported in small parts. Very large reports or imports can still take longer, and available disk space and Nari's memory budget remain practical limits.

Existing history is converted automatically on first launch. The old journal is removed only after all its records have been saved in the new format. Keep every exported backup part when restoring. All history remains local.

By Pirate2122yt
